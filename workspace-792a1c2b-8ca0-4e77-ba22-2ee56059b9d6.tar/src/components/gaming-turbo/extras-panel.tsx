"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BellOff,
  BatteryLow,
  SunMedium,
  Video,
  Square,
  Bell,
  ShieldCheck,
} from "lucide-react";
import { NeonCard, GlowTitle, NeonButton, ToggleNeon, Chip } from "./neon";
import { useTurboStore } from "@/lib/store";
import { sound } from "@/lib/sound-engine";
import { useRealMetrics } from "@/lib/metrics";

export function ExtrasPanel() {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <NotificationShield />
      <BatterySaverCard />
      <BrightnessCard />
      <CaptureCard />
    </div>
  );
}

function NotificationShield() {
  const notifShield = useTurboStore((s) => s.settings.notifShield);
  const blockedNotifs = useTurboStore((s) => s.settings.blockedNotifs);
  const updateSettings = useTurboStore((s) => s.updateSettings);
  const [incoming, setIncoming] = useState<string | null>(null);

  const FAKE_NOTIFS = [
    "Soccer scores: GOAL! 87'",
    "Email: 50% off sale ends today",
    "Social: 3 new followers",
    "Update available: SomeApp 4.2.1",
    "Chat: 12 unread messages",
  ];

  useEffect(() => {
    if (!notifShield) {
      setIncoming(null);
      return;
    }
    const timers: number[] = [];
    const blockedNotifsBase = useTurboStore.getState().settings.blockedNotifs;
    const FAKE_POOL = FAKE_NOTIFS;
    let i = 0;
    const iv = window.setInterval(() => {
      setIncoming(FAKE_POOL[i % FAKE_POOL.length]);
      sound.zap();
      updateSettings({ blockedNotifs: blockedNotifsBase + i + 1 });
      i++;
      const t = window.setTimeout(() => setIncoming(null), 1400);
      timers.push(t);
    }, 4200);
    return () => {
      window.clearInterval(iv);
      timers.forEach((t) => window.clearTimeout(t));
    };
  }, [notifShield]);

  return (
    <NeonCard className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <GlowTitle color="magenta">Notification Shield</GlowTitle>
        <Chip color={notifShield ? "lime" : "slate"}>
          {notifShield ? "ARMED" : "OFF"}
        </Chip>
      </div>
      <ToggleNeon
        color="magenta"
        checked={notifShield}
        onCheckedChange={(v) => updateSettings({ notifShield: v })}
        label="Block pop-ups while gaming"
        description="Simulates intercepting desktop notifications mid-game. Each intercepted pop-up increments your session counter."
      />
      <div className="mt-5 flex items-center justify-between rounded-lg border border-fuchsia-400/15 bg-black/40 px-4 py-3">
        <div className="flex items-center gap-3">
          <div
            className={`flex h-10 w-10 items-center justify-center rounded-full border ${
              notifShield
                ? "border-lime-400/50 bg-lime-400/10 text-lime-300"
                : "border-white/10 bg-white/[0.04] text-slate-500"
            }`}
          >
            {notifShield ? <ShieldCheck className="h-5 w-5" /> : <Bell className="h-5 w-5" />}
          </div>
          <div>
            <div className="font-mono-data text-xl font-black text-slate-100">{blockedNotifs}</div>
            <div className="text-[9px] uppercase tracking-widest text-slate-500">blocked total</div>
          </div>
        </div>
        <div className="h-12 w-40 overflow-hidden rounded-md border border-white/[0.08] bg-black/60 p-2">
          <AnimatePresence mode="wait">
            {incoming ? (
              <motion.div
                key={incoming}
                initial={{ x: 160, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -160, opacity: 0, filter: "blur(2px)" }}
                transition={{ duration: 0.35 }}
                className="flex items-center gap-2"
              >
                <BellOff className="h-3.5 w-3.5 shrink-0 text-rose-400" />
                <span className="truncate text-[10px] text-slate-400 line-through">{incoming}</span>
                <span className="ml-auto shrink-0 text-[8px] font-bold uppercase text-rose-400">
                  blocked
                </span>
              </motion.div>
            ) : (
              <motion.div
                key="idle"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex h-full items-center justify-center text-[9px] uppercase tracking-widest text-slate-700"
              >
                {notifShield ? "listening..." : "shield idle"}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </NeonCard>
  );
}

function BatterySaverCard() {
  const batterySaver = useTurboStore((s) => s.settings.batterySaver);
  const updateSettings = useTurboStore((s) => s.updateSettings);
  const m = useRealMetrics();

  useEffect(() => {
    document.documentElement.classList.toggle("turbo-lowpower", batterySaver);
    return () => document.documentElement.classList.remove("turbo-lowpower");
  }, [batterySaver]);

  return (
    <NeonCard variant="lime" className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <GlowTitle color="lime">Battery Saver</GlowTitle>
        <Chip color={batterySaver ? "lime" : "slate"}>{batterySaver ? "ECO ON" : "FULL POWER"}</Chip>
      </div>
      <ToggleNeon
        color="lime"
        checked={batterySaver}
        onCheckedChange={(v) => updateSettings({ batterySaver: v })}
        label="Throttle decorative effects"
        description="Pauses scan beams, flicker and glitch animations to save real battery. Uses the live Battery API below."
      />
      <div className="mt-5 rounded-lg border border-lime-400/15 bg-black/40 p-4">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-xs text-slate-400">
            <BatteryLow className="h-4 w-4 text-lime-400" /> Real battery status
          </span>
          <span className="font-mono-data text-sm font-bold text-lime-300">
            {m.battery ? `${m.battery.level}%` : "API N/A"}
          </span>
        </div>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/[0.06]">
          <div
            className="h-full rounded-full bg-gradient-to-r from-lime-400 to-emerald-500 transition-[width] duration-700"
            style={{ width: `${m.battery?.level ?? 0}%` }}
          />
        </div>
        <p className="mt-2 text-[10px] text-slate-600">
          {m.battery
            ? m.battery.charging
              ? "Charging — full FX recommended."
              : "On battery — eco mode recommended below 30%."
            : "Battery API not exposed by this browser (Safari/Firefox)."}
        </p>
      </div>
    </NeonCard>
  );
}

function BrightnessCard() {
  const brightness = useTurboStore((s) => s.settings.brightness);
  const updateSettings = useTurboStore((s) => s.updateSettings);
  const dim = Math.min(70, Math.max(0, 100 - brightness));

  return (
    <NeonCard className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <GlowTitle>Brightness Lock</GlowTitle>
        <Chip color="cyan">{brightness}%</Chip>
      </div>
      <div className="flex items-start gap-4">
        <SunMedium className="mt-1 h-5 w-5 shrink-0 text-amber-300" />
        <div className="flex-1">
          <p className="text-xs leading-relaxed text-slate-500">
            Lock a screen dim level for night sessions. Applied as a fullscreen overlay on top of
            the app.
          </p>
          <input
            type="range"
            min={40}
            max={100}
            value={brightness}
            aria-label="Brightness level"
            onChange={(e) => {
              updateSettings({ brightness: Number(e.target.value) });
            }}
            onMouseUp={() => sound.tick()}
            className="mt-4 w-full accent-cyan-400"
          />
          <div className="mt-1 flex justify-between text-[9px] uppercase tracking-widest text-slate-600">
            <span>40% dim deep</span>
            <span>100% full</span>
          </div>
        </div>
      </div>
      <div
        className="pointer-events-none fixed inset-0 z-[70] bg-black transition-opacity duration-500"
        style={{ opacity: dim / 100 }}
        aria-hidden
      />
    </NeonCard>
  );
}

function CaptureCard() {
  const [recording, setRecording] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const startRec = async () => {
    setError(null);
    if (typeof navigator === "undefined" || !navigator.mediaDevices?.getDisplayMedia) {
      setError("Screen capture is not supported in this browser.");
      sound.error();
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const mime = MediaRecorder.isTypeSupported("video/webm;codecs=vp9")
        ? "video/webm;codecs=vp9"
        : "video/webm";
      const rec = new MediaRecorder(stream, { mimeType: mime });
      chunksRef.current = [];
      rec.ondataavailable = (e) => e.data.size > 0 && chunksRef.current.push(e.data);
      rec.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: "video/webm" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `turbo-capture-${Date.now()}.webm`;
        a.click();
        URL.revokeObjectURL(url);
        setRecording(false);
        sound.chime();
      };
      stream.getVideoTracks()[0].addEventListener("ended", () => {
        if (rec.state !== "inactive") rec.stop();
      });
      rec.start();
      recRef.current = rec;
      setRecording(true);
      sound.whoosh(true);
    } catch {
      setError("Capture permission denied or cancelled.");
      sound.error();
    }
  };

  const stopRec = () => {
    recRef.current?.stop();
  };

  return (
    <NeonCard variant="magenta" className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <GlowTitle color="magenta">Game Capture</GlowTitle>
        {recording && (
          <span className="flex items-center gap-1.5">
            <motion.span
              className="h-2.5 w-2.5 rounded-full bg-rose-500"
              animate={{ opacity: [1, 0.3, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
            <Chip color="magenta">REC</Chip>
          </span>
        )}
      </div>
      <p className="text-xs leading-relaxed text-slate-500">
        Record your screen to a downloadable .webm clip using the real browser MediaRecorder —
        great for clipping clutch moments without third-party software.
      </p>
      <div className="mt-4 flex items-center gap-3">
        {!recording ? (
          <NeonButton variant="magenta" onClick={startRec}>
            <Video className="h-4 w-4" /> Start Capture
          </NeonButton>
        ) : (
          <NeonButton variant="danger" onClick={stopRec}>
            <Square className="h-4 w-4" /> Stop &amp; Save
          </NeonButton>
        )}
      </div>
      {error && <p className="mt-3 text-xs text-rose-400">{error}</p>}
    </NeonCard>
  );
}
