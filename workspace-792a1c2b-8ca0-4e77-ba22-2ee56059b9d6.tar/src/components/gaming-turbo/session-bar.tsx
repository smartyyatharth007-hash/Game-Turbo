"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Timer, Undo2, Ban, CheckCircle2 } from "lucide-react";
import { useTurboStore } from "@/lib/store";
import { sound } from "@/lib/sound-engine";
import { NeonButton } from "./neon";
import { useToast } from "@/hooks/use-toast";

function fmtElapsed(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return [h, m, sec].map((v) => String(v).padStart(2, "0")).join(":");
}

export function SessionBar() {
  const session = useTurboStore((s) => s.session);
  const endSession = useTurboStore((s) => s.endSession);
  const [tick, setTick] = useState(0);
  const { toast } = useToast();

  useEffect(() => {
    if (!session) return;
    const iv = window.setInterval(() => setTick((n) => n + 1), 1000);
    return () => window.clearInterval(iv);
  }, [session]);

  return (
    <AnimatePresence>
      {session && (
        <motion.div
          initial={{ y: 90, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 90, opacity: 0 }}
          transition={{ type: "spring", stiffness: 240, damping: 26 }}
          className="fixed inset-x-3 bottom-3 z-[85] mx-auto max-w-4xl sm:inset-x-6"
        >
          <div className="rgb-border flex flex-col gap-3 rounded-xl bg-[#0a0a16]/95 p-4 backdrop-blur-md sm:flex-row sm:items-center sm:justify-between">
            <div className="flex min-w-0 items-center gap-3">
              <div className="animate-pulse-glow flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-lime-400/50 bg-lime-400/10">
                <Timer className="h-5 w-5 text-lime-300" />
              </div>
              <div className="min-w-0">
                <div className="font-display truncate text-sm font-bold text-slate-100">
                  SESSION // {session.gameName.toUpperCase().slice(0, 26)}
                </div>
                <div className="font-mono-data text-[11px] text-lime-300">
                  {fmtElapsed(Date.now() - session.startedAt)} elapsed
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="hidden items-center gap-1.5 rounded-md border border-rose-400/30 bg-rose-400/[0.07] px-2 py-1.5 text-[9px] font-bold uppercase tracking-wider text-rose-300 lg:flex">
                <Ban className="h-3 w-3" /> {session.disabledExtras.length} extras disabled
              </span>
              <NeonButton
                variant="lime"
                size="sm"
                onClick={() => {
                  const restored = endSession();
                  if (restored) {
                    sound.chime();
                    toast({
                      title: "Extras restored",
                      description: `Session ended — ${restored.disabledExtras.length} disabled extras re-enabled: ${restored.disabledExtras.join(", ")}.`,
                    });
                  }
                }}
              >
                <Undo2 className="h-3.5 w-3.5" /> End Session — Restore Extras
              </NeonButton>
            </div>
          </div>
          <span className="sr-only" aria-live="polite">
            <CheckCircle2 /> Ending the session restores all disabled extras.
          </span>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
