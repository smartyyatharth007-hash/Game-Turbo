"use client";

import { useMemo } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  YAxis,
} from "recharts";
import { Cpu, Gpu, MemoryStick, MonitorSmartphone, Wifi, BatteryCharging, BatteryFull, Gauge } from "lucide-react";
import { NeonCard, GlowTitle, Chip, StatBar } from "./neon";
import { useRealMetrics } from "@/lib/metrics";
import { useTurboStore } from "@/lib/store";

const FPS_MAX = 165;

export function PerformanceHUD() {
  const m = useRealMetrics();
  const boostLevel = useTurboStore((s) => s.boostLevel);
  const batterySaver = useTurboStore((s) => s.settings.batterySaver);

  const fpsData = useMemo(() => m.fpsHistory.map((v, i) => ({ i, fps: v })), [m.fpsHistory]);
  const heapData = useMemo(() => m.heapHistory.map((v, i) => ({ i, mb: v })), [m.heapHistory]);
  const rttData = useMemo(() => m.rttHistory.map((v, i) => ({ i, ms: v })), [m.rttHistory]);

  // Simulated system load (browsers don't expose CPU/GPU load) — boosted state lowers it
  const cpuLoad = useMemo(
    () => Math.round(58 + 12 * Math.sin(Date.now() / 2600) - boostLevel * 0.22),
    [boostLevel, m.fps]
  );
  const gpuLoad = useMemo(
    () => Math.round(47 + 14 * Math.sin(Date.now() / 3400 + 2) - boostLevel * 0.18),
    [boostLevel, m.fps]
  );

  const heapPct =
    m.heapUsedMB !== null && m.heapLimitMB ? (m.heapUsedMB / m.heapLimitMB) * 100 : null;

  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {/* FPS */}
      <NeonCard className="p-5">
        <div className="mb-3 flex items-center justify-between">
          <GlowTitle>Framerate</GlowTitle>
          <Chip color="lime">LIVE rAF</Chip>
        </div>
        <div className="flex items-end gap-3">
          <span className="font-display text-5xl font-black tabular-nums text-cyan-300 text-glow-cyan">
            {m.fps || "--"}
          </span>
          <span className="pb-2 text-xs uppercase tracking-widest text-slate-500">FPS real-time</span>
        </div>
        <div className="mt-3 h-28">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={fpsData} margin={{ top: 4, right: 4, bottom: 0, left: -22 }}>
              <defs>
                <linearGradient id="fpsFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00f0ff" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="#00f0ff" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="rgba(0,240,255,0.08)" vertical={false} />
              <YAxis domain={[0, FPS_MAX]} tick={{ fill: "#5c6b8a", fontSize: 9 }} width={34} />
              <Tooltip
                contentStyle={{
                  background: "#0d0d1a",
                  border: "1px solid rgba(0,240,255,0.3)",
                  borderRadius: 8,
                  fontSize: 11,
                }}
                labelFormatter={() => ""}
                formatter={(v) => [`${v} fps`, "FPS"]}
              />
              <Area
                type="monotone"
                dataKey="fps"
                stroke="#00f0ff"
                strokeWidth={2}
                fill="url(#fpsFill)"
                isAnimationActive={false}
                dot={false}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </NeonCard>

      {/* Memory */}
      <NeonCard variant="magenta" className="p-5">
        <div className="mb-3 flex items-center justify-between">
          <GlowTitle color="magenta">Memory</GlowTitle>
          <Chip color={m.heapUsedMB !== null ? "lime" : "amber"}>
            {m.heapUsedMB !== null ? "LIVE heap" : "NOT EXPOSED"}
          </Chip>
        </div>
        <div className="flex items-center gap-2 text-slate-300">
          <MemoryStick className="h-4 w-4 text-fuchsia-400" />
          <span className="font-mono-data text-2xl font-bold">
            {m.heapUsedMB !== null ? `${m.heapUsedMB} MB` : "N/A"}
          </span>
          {m.heapLimitMB !== null && (
            <span className="pb-1 text-xs text-slate-500">/ {m.heapLimitMB} MB limit</span>
          )}
        </div>
        {m.heapUsedMB === null && (
          <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
            This browser does not expose JS heap metrics. Open in Chrome / Edge for live memory
            telemetry.
          </p>
        )}
        <div className="mt-3 h-24">
          {m.heapUsedMB !== null ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={heapData} margin={{ top: 4, right: 4, bottom: 0, left: -22 }}>
                <defs>
                  <linearGradient id="heapFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#ff2ee6" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#ff2ee6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <YAxis tick={{ fill: "#5c6b8a", fontSize: 9 }} width={34} />
                <Tooltip
                  contentStyle={{
                    background: "#0d0d1a",
                    border: "1px solid rgba(255,46,230,0.3)",
                    borderRadius: 8,
                    fontSize: 11,
                  }}
                  labelFormatter={() => ""}
                  formatter={(v) => [`${v} MB`, "Heap"]}
                />
                <Area
                  type="monotone"
                  dataKey="mb"
                  stroke="#ff2ee6"
                  strokeWidth={2}
                  fill="url(#heapFill)"
                  isAnimationActive={false}
                  dot={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex h-full items-center justify-center rounded-lg border border-fuchsia-400/10 bg-black/30 text-[10px] uppercase tracking-widest text-slate-600">
              Waiting for heap API
            </div>
          )}
        </div>
        {heapPct !== null && (
          <div className="mt-3">
            <StatBar label="Heap pressure" value={heapPct} gradient="from-fuchsia-400 to-rose-500" />
          </div>
        )}
      </NeonCard>

      {/* System */}
      <NeonCard className="p-5">
        <div className="mb-3 flex items-center justify-between">
          <GlowTitle>System</GlowTitle>
          <Chip color="cyan">DEVICE</Chip>
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-2 text-xs text-slate-400">
              <Cpu className="h-4 w-4 text-cyan-400" /> CPU threads
            </span>
            <span className="font-mono-data text-sm font-bold text-slate-200">
              {m.cores ?? "N/A"}
            </span>
          </div>
          <div className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-2 text-xs text-slate-400">
              <Gpu className="h-4 w-4 text-cyan-400" /> GPU
            </span>
            <span
              className="font-mono-data max-w-[180px] truncate text-right text-xs font-bold text-slate-200"
              title={m.gpu}
            >
              {m.gpu ? shortenGpu(m.gpu) : "N/A"}
            </span>
          </div>
          <div className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-2 text-xs text-slate-400">
              <MonitorSmartphone className="h-4 w-4 text-cyan-400" /> Screen
            </span>
            <span className="font-mono-data text-xs font-bold text-slate-200">
              {m.screen || "N/A"}
            </span>
          </div>
          <div className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-2 text-xs text-slate-400">
              {m.battery ? (
                m.battery.charging ? (
                  <BatteryCharging className="h-4 w-4 text-lime-400" />
                ) : (
                  <BatteryFull className="h-4 w-4 text-amber-400" />
                )
              ) : (
                <BatteryFull className="h-4 w-4 text-slate-600" />
              )}
              Battery
            </span>
            <span className="font-mono-data text-xs font-bold text-slate-200">
              {m.battery
                ? `${m.battery.level}%${m.battery.charging ? " CHG" : ""}`
                : "N/A"}
            </span>
          </div>
          <div className="space-y-2.5 border-t border-white/[0.06] pt-3">
            <StatBar label="CPU load" value={cpuLoad} sim gradient="from-cyan-400 to-fuchsia-500" />
            <StatBar
              label="GPU load"
              value={gpuLoad}
              sim
              gradient="from-fuchsia-400 to-rose-500"
            />
          </div>
        </div>
      </NeonCard>

      {/* Network */}
      <NeonCard variant="lime" className="p-5 md:col-span-2 xl:col-span-3">
        <div className="mb-3 flex items-center justify-between">
          <GlowTitle color="lime">Network</GlowTitle>
          <div className="flex gap-2">
            <Chip color="lime">LIVE RTT</Chip>
            <Chip color="slate">{m.netType.toUpperCase()}</Chip>
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Wifi className="h-4 w-4 text-lime-400" /> Round-trip latency
            </div>
            <div className="font-mono-data mt-1 text-3xl font-black text-lime-300 text-glow-lime">
              {m.rtt !== null ? `${m.rtt}` : "--"}
              <span className="ml-1 text-sm text-slate-500">ms</span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Gauge className="h-4 w-4 text-lime-400" /> Downlink
            </div>
            <div className="font-mono-data mt-1 text-3xl font-black text-slate-100">
              {m.downlink !== null ? `${m.downlink}` : "--"}
              <span className="ml-1 text-sm text-slate-500">Mb/s</span>
            </div>
          </div>
          <div className="h-20">
            {rttData.length > 1 ? (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={rttData} margin={{ top: 4, right: 4, bottom: 0, left: -28 }}>
                  <YAxis tick={{ fill: "#5c6b8a", fontSize: 9 }} width={38} />
                  <Tooltip
                    contentStyle={{
                      background: "#0d0d1a",
                      border: "1px solid rgba(182,255,0,0.3)",
                      borderRadius: 8,
                      fontSize: 11,
                    }}
                    labelFormatter={() => ""}
                    formatter={(v) => [`${v} ms`, "RTT"]}
                  />
                  <Line
                    type="monotone"
                    dataKey="ms"
                    stroke="#b6ff00"
                    strokeWidth={2}
                    isAnimationActive={false}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center rounded-lg border border-lime-400/10 bg-black/30 text-[10px] uppercase tracking-widest text-slate-600">
                Sampling network...
              </div>
            )}
          </div>
        </div>
        <p className="mt-2 text-[10px] leading-relaxed text-slate-600">
          Battery saver {batterySaver ? "ON — decorative animations paused" : "OFF — full FX"}.
          CPU/GPU load bars are simulated (browsers do not expose them); all other values are
          measured live from your device.
        </p>
      </NeonCard>
    </div>
  );
}

function shortenGpu(gpu: string): string {
  return gpu
    .replace("ANGLE (", "")
    .replace(/\)$/, "")
    .replace("Direct3D11", "D3D11")
    .replace("vs_5_0", "")
    .replace("ps_5_0", "")
    .replace(/,\s*/g, ", ")
    .split(", ")
    .slice(0, 3)
    .join(" · ")
    .slice(0, 42);
}
