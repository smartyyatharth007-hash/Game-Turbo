"use client";

import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from "react";
import { sound } from "@/lib/sound-engine";
import { cn } from "@/lib/utils";

export function NeonCard({
  children,
  className,
  variant = "cyan",
}: {
  children: ReactNode;
  className?: string;
  variant?: "cyan" | "magenta" | "lime";
}) {
  return (
    <div
      className={cn(
        "neon-card rounded-xl",
        variant === "magenta" && "neon-card-magenta",
        variant === "lime" && "neon-card-lime",
        className
      )}
    >
      {children}
    </div>
  );
}

export function GlowTitle({
  children,
  color = "cyan",
  className,
}: {
  children: ReactNode;
  color?: "cyan" | "magenta" | "lime";
  className?: string;
}) {
  return (
    <h2
      className={cn(
        "font-display text-sm font-bold uppercase tracking-[0.25em]",
        color === "cyan" && "text-cyan-300 text-glow-cyan",
        color === "magenta" && "text-fuchsia-400 text-glow-magenta",
        color === "lime" && "text-lime-300 text-glow-lime",
        className
      )}
    >
      {children}
    </h2>
  );
}

type NeonButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "cyan" | "magenta" | "lime" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
  silent?: boolean;
};

export const NeonButton = forwardRef<HTMLButtonElement, NeonButtonProps>(
  ({ className, variant = "cyan", size = "md", silent, onClick, ...props }, ref) => {
    return (
      <button
        ref={ref}
        onClick={(e) => {
          if (!silent) sound.click();
          onClick?.(e);
        }}
        className={cn(
          "font-display inline-flex items-center justify-center gap-2 rounded-md font-bold uppercase tracking-widest transition-all duration-200 focus-visible:outline-2 disabled:cursor-not-allowed disabled:opacity-40",
          size === "sm" && "px-3 py-1.5 text-[10px]",
          size === "md" && "px-4 py-2 text-xs",
          size === "lg" && "px-6 py-3 text-sm",
          variant === "cyan" &&
            "border border-cyan-400/60 bg-cyan-400/10 text-cyan-200 hover:bg-cyan-400/25 hover:shadow-[0_0_18px_rgba(0,240,255,0.45)] active:scale-[0.97]",
          variant === "magenta" &&
            "border border-fuchsia-400/60 bg-fuchsia-400/10 text-fuchsia-200 hover:bg-fuchsia-400/25 hover:shadow-[0_0_18px_rgba(255,46,230,0.45)] active:scale-[0.97]",
          variant === "lime" &&
            "border border-lime-400/60 bg-lime-400/10 text-lime-200 hover:bg-lime-400/25 hover:shadow-[0_0_18px_rgba(182,255,0,0.45)] active:scale-[0.97]",
          variant === "danger" &&
            "border border-rose-500/60 bg-rose-500/10 text-rose-300 hover:bg-rose-500/25 hover:shadow-[0_0_18px_rgba(255,61,110,0.45)] active:scale-[0.97]",
          variant === "ghost" &&
            "border border-white/10 bg-white/[0.03] text-slate-300 hover:bg-white/10 active:scale-[0.97]",
          className
        )}
        {...props}
      />
    );
  }
);
NeonButton.displayName = "NeonButton";

export function Chip({
  children,
  color = "cyan",
  className,
}: {
  children: ReactNode;
  color?: "cyan" | "magenta" | "lime" | "amber" | "slate";
  className?: string;
}) {
  return (
    <span
      className={cn(
        "font-display inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider",
        color === "cyan" && "border-cyan-400/40 bg-cyan-400/10 text-cyan-300",
        color === "magenta" && "border-fuchsia-400/40 bg-fuchsia-400/10 text-fuchsia-300",
        color === "lime" && "border-lime-400/40 bg-lime-400/10 text-lime-300",
        color === "amber" && "border-amber-400/40 bg-amber-400/10 text-amber-300",
        color === "slate" && "border-white/15 bg-white/5 text-slate-400",
        className
      )}
    >
      {children}
    </span>
  );
}

export function StatBar({
  label,
  value,
  gradient = "from-cyan-400 to-blue-500",
  suffix = "%",
  sim = false,
}: {
  label: string;
  value: number;
  gradient?: string;
  suffix?: string;
  sim?: boolean;
}) {
  const clamped = Math.max(0, Math.min(100, value));
  return (
    <div>
      <div className="mb-1 flex items-center justify-between">
        <span className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
          {label}
          {sim && (
            <span className="rounded-sm border border-amber-400/40 px-1 text-[8px] font-bold text-amber-400/90">
              SIM
            </span>
          )}
        </span>
        <span className="font-mono-data text-xs font-bold text-slate-200">
          {Math.round(value)}
          {suffix}
        </span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/[0.06]">
        <div
          className={cn("h-full rounded-full bg-gradient-to-r transition-[width] duration-500", gradient)}
          style={{ width: `${clamped}%` }}
        />
      </div>
    </div>
  );
}

export function ToggleNeon({
  checked,
  onCheckedChange,
  color = "cyan",
  label,
  description,
}: {
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
  color?: "cyan" | "magenta" | "lime";
  label: string;
  description?: string;
}) {
  const knob = (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => {
        sound.toggle(!checked);
        onCheckedChange(!checked);
      }}
      className={cn(
        "relative h-6 w-11 shrink-0 rounded-full border transition-all duration-300",
        checked &&
          color === "cyan" &&
          "border-cyan-400/70 bg-cyan-400/25 shadow-[0_0_14px_rgba(0,240,255,0.4)]",
        checked &&
          color === "magenta" &&
          "border-fuchsia-400/70 bg-fuchsia-400/25 shadow-[0_0_14px_rgba(255,46,230,0.4)]",
        checked &&
          color === "lime" &&
          "border-lime-400/70 bg-lime-400/25 shadow-[0_0_14px_rgba(182,255,0,0.4)]",
        !checked && "border-white/15 bg-white/[0.06]"
      )}
    >
      <span
        className={cn(
          "absolute top-1/2 h-4 w-4 -translate-y-1/2 rounded-full transition-all duration-300",
          checked &&
            color === "cyan" &&
            "left-[24px] bg-cyan-300 shadow-[0_0_8px_rgba(0,240,255,0.9)]",
          checked &&
            color === "magenta" &&
            "left-[24px] bg-fuchsia-300 shadow-[0_0_8px_rgba(255,46,230,0.9)]",
          checked &&
            color === "lime" &&
            "left-[24px] bg-lime-300 shadow-[0_0_8px_rgba(182,255,0,0.9)]",
          !checked && "left-[4px] bg-slate-400"
        )}
      />
    </button>
  );
  if (!description) return knob;
  return (
    <div className="flex items-start justify-between gap-4">
      <div>
        <div className="text-sm font-semibold text-slate-200">{label}</div>
        {description && <div className="mt-0.5 text-xs text-slate-500">{description}</div>}
      </div>
      {knob}
    </div>
  );
}
