"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  X, ArrowLeft, Play, Star, ShieldCheck, AlertTriangle, XCircle, HelpCircle,
  Cpu, MemoryStick, Gpu, Wrench, Timer,
} from "lucide-react";
import { NeonButton, Chip } from "./neon";
import { checkSpec, detectGpuTier, type HardwareInput, type SpecCheckResult } from "@/lib/games-db";
import { useTurboStore } from "@/lib/store";
import { sound } from "@/lib/sound-engine";
import { downloadText, buildGameModeOnScript, buildGameModeOffScript } from "@/lib/ps-scripts";
import { metricsStore } from "@/lib/metrics";
import type { TurboGame } from "@/lib/types";

const VERDICT_UI = {
  YES: { icon: ShieldCheck, color: "text-lime-300", ring: "border-lime-400/50 bg-lime-400/10", label: "CAN RUN — FULL SETTINGS" },
  LOW: { icon: AlertTriangle, color: "text-amber-300", ring: "border-amber-400/50 bg-amber-400/10", label: "CAN RUN — LOWER SETTINGS" },
  NO: { icon: XCircle, color: "text-rose-300", ring: "border-rose-400/50 bg-rose-400/10", label: "BELOW MINIMUM" },
  UNKNOWN: { icon: HelpCircle, color: "text-slate-300", ring: "border-white/20 bg-white/5", label: "NOT IN REQUIREMENTS DB" },
} as const;

export function GameDetailDrawer({
  game,
  onClose,
  onLaunchSession,
}: {
  game: TurboGame;
  onClose: () => void;
  onLaunchSession: (g: TurboGame) => void;
}) {
  const pinnedId = useTurboStore((s) => s.pinnedId);
  const setPinned = useTurboStore((s) => s.setPinned);
  const [cores, setCores] = useState(() => metricsStore.getState().cores ?? 4);
  const [ram, setRam] = useState(() => Math.max(8, metricsStore.getState().deviceMemoryGB ?? 8));
  const [gpu, setGpu] = useState(() => metricsStore.getState().gpu || "");
  const [bench, setBench] = useState(() => useTurboStore.getState().benchHistory.at(-1)?.total ?? 0);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const hw: HardwareInput = useMemo(
    () => ({ cores, ramGB: ram, gpuString: gpu, benchScore: bench }),
    [cores, ram, gpu, bench]
  );
  const result: SpecCheckResult = useMemo(() => checkSpec(game.name, hw), [game.name, hw]);
  const V = VERDICT_UI[result.verdict];

  const pinned = pinnedId === game.id;

  return (
    <motion.div
      className="fixed inset-0 z-[92] flex justify-end bg-black/70 backdrop-blur-sm"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <motion.aside
        role="dialog"
        aria-label={`${game.name} details`}
        className="scrollbar-neon h-full w-full max-w-lg overflow-y-auto border-l border-cyan-400/25 bg-[#08080f] p-6"
        initial={{ x: 60, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: 60, opacity: 0 }}
        transition={{ type: "spring", stiffness: 260, damping: 28 }}
      >
        <div className="mb-5 flex items-center justify-between">
          <NeonButton variant="ghost" size="sm" onClick={onClose}>
            <ArrowLeft className="h-3.5 w-3.5" /> Back
          </NeonButton>
          <button
            aria-label="Close details"
            onClick={onClose}
            className="rounded-md border border-white/10 p-1.5 text-slate-400 hover:bg-white/10"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex items-center gap-4">
          <div
            className="font-display flex h-16 w-16 items-center justify-center rounded-xl text-2xl font-black text-black/85"
            style={{
              background: `linear-gradient(135deg, ${game.gradient[0]}, ${game.gradient[1]})`,
              boxShadow: `0 0 26px ${game.gradient[0]}55`,
            }}
          >
            {game.name.split(/[\s:]+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase()}
          </div>
          <div className="min-w-0">
            <h3 className="font-display truncate text-lg font-black text-slate-100">{game.name}</h3>
            <p className="text-xs text-slate-500">
              {result.found ? `${result.title} · ${result.genre}` : game.genre || "Auto-details: title not in requirements DB"}
            </p>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              <Chip color="slate">{game.platform}</Chip>
              {game.isCustom && <Chip color="magenta">CUSTOM</Chip>}
              {pinned && <Chip color="amber">MY TURBO</Chip>}
            </div>
          </div>
        </div>

        {/* Auto spec check */}
        <div className={`mt-6 rounded-xl border p-4 ${V.ring}`}>
          <div className="flex items-center gap-3">
            <V.icon className={`h-7 w-7 ${V.color}`} />
            <div>
              <div className={`font-display text-sm font-black tracking-wider ${V.color}`}>{V.label}</div>
              <div className="text-[10px] uppercase tracking-widest text-slate-500">
                Auto spec check · GPU tier {result.gpuTier}/10 ({result.gpuLabel})
              </div>
            </div>
          </div>
        </div>

        {/* Hardware inputs */}
        <div className="mt-5 rounded-xl border border-white/10 bg-black/30 p-4">
          <div className="mb-3 flex items-center justify-between">
            <span className="font-display text-[10px] font-bold uppercase tracking-[0.25em] text-slate-400">
              Your hardware (auto-detected, editable)
            </span>
            {bench > 0 && <Chip color="lime">TurboScore {bench}</Chip>}
          </div>
          <div className="grid grid-cols-3 gap-3">
            <Field label="CPU cores" type="number" min={1} max={64} value={cores} onChange={(v) => setCores(Math.max(1, Math.min(64, v)))} />
            <Field label="RAM (GB)" type="number" min={1} max={128} value={ram} onChange={(v) => setRam(Math.max(1, Math.min(128, v)))} />
            <Field label="TurboScore" type="number" min={0} max={100} value={bench} onChange={(v) => setBench(Math.max(0, Math.min(100, v)))} />
          </div>
          <div className="mt-3">
            <label className="mb-1 block text-[9px] font-bold uppercase tracking-widest text-slate-500">GPU string</label>
            <input
              value={gpu}
              onChange={(e) => setGpu(e.target.value)}
              className="font-mono-data w-full rounded-md border border-white/10 bg-black/40 px-3 py-2 text-xs text-slate-200 focus:border-cyan-400/50 focus:outline-none"
            />
          </div>
        </div>

        {/* Requirements table */}
        {result.reqs && (
          <div className="mt-5 overflow-hidden rounded-xl border border-white/10">
            <table className="w-full text-left text-xs">
              <thead className="bg-white/[0.04] text-[9px] uppercase tracking-widest text-slate-500">
                <tr>
                  <th className="px-3 py-2">Component</th>
                  <th className="px-3 py-2">Minimum</th>
                  <th className="px-3 py-2">Recommended</th>
                  <th className="px-3 py-2">Yours</th>
                </tr>
              </thead>
              <tbody className="text-slate-300">
                <ReqRow icon={<Cpu className="h-3.5 w-3.5 text-cyan-400" />} name="CPU cores" min={`${result.reqs.minCores}`} rec={`${result.reqs.minCores + 2}+`} you={`${cores}`} pass={result.cpuPass} />
                <ReqRow icon={<Gpu className="h-3.5 w-3.5 text-fuchsia-400" />} name="GPU tier" min={`${result.reqs.minGpuTier}/10`} rec={`${result.reqs.recGpuTier}/10`} you={`${result.gpuTier}/10`} pass={result.gpuPass} />
                <ReqRow icon={<MemoryStick className="h-3.5 w-3.5 text-lime-400" />} name="RAM" min={`${result.reqs.minRam} GB`} rec={`${result.reqs.recRam} GB`} you={`${ram} GB`} pass={result.ramPass} />
              </tbody>
            </table>
          </div>
        )}

        {/* Recommendations */}
        <div className="mt-5">
          <div className="font-display mb-2 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[0.25em] text-slate-400">
            <Wrench className="h-3.5 w-3.5 text-amber-300" /> What you need to run {result.found ? result.title : "this game"}
          </div>
          <ul className="space-y-2">
            {result.recommendations.map((r, i) => (
              <li key={i} className="rounded-lg border border-white/[0.07] bg-white/[0.02] px-3 py-2 text-xs leading-relaxed text-slate-300">
                {r}
              </li>
            ))}
          </ul>
        </div>

        {/* Actions */}
        <div className="mt-6 grid grid-cols-2 gap-2">
          <NeonButton
            variant="cyan"
            className="col-span-2"
            onClick={() => {
              sound.engineRev(1.4);
              onLaunchSession(game);
            }}
          >
            <Play className="h-4 w-4" /> Start Turbo Session
          </NeonButton>
          <NeonButton
            variant={pinned ? "magenta" : "ghost"}
            onClick={() => {
              sound.toggle(!pinned);
              setPinned(pinned ? null : game.id);
            }}
          >
            <Star className={`h-3.5 w-3.5 ${pinned ? "fill-amber-300 text-amber-300" : ""}`} />
            {pinned ? "My Turbo Target" : "Set as My Turbo"}
          </NeonButton>
          <NeonButton
            variant="lime"
            onClick={() => downloadText("TurboGameMode-ON.ps1", buildGameModeOnScript())}
          >
            <Timer className="h-3.5 w-3.5" /> Game Mode ON script
          </NeonButton>
        </div>
        <p className="mt-3 text-[10px] leading-relaxed text-slate-600">
          Starting a session switches on DND + Notification Shield in-app and hands you the Windows
          script that disables widgets, animations, transparency and GameDVR. When you end the
          session, Gaming Turbo automatically restores every extra it disabled — and Game Mode OFF
          script reverts Windows.
        </p>
      </motion.aside>
    </motion.div>
  );
}

function ReqRow({
  icon, name, min, rec, you, pass,
}: {
  icon: React.ReactNode; name: string; min: string; rec: string; you: string; pass: boolean;
}) {
  return (
    <tr className="border-t border-white/[0.06]">
      <td className="flex items-center gap-2 px-3 py-2 font-semibold text-slate-200">{icon}{name}</td>
      <td className="px-3 py-2 text-slate-400">{min}</td>
      <td className="px-3 py-2 text-slate-400">{rec}</td>
      <td className={`px-3 py-2 font-bold ${pass ? "text-lime-300" : "text-rose-300"}`}>{you} {pass ? "OK" : "LOW"}</td>
    </tr>
  );
}

function Field({
  label, value, onChange, type = "text", min, max,
}: {
  label: string; value: number; onChange: (v: number) => void; type?: string; min?: number; max?: number;
}) {
  return (
    <div>
      <label className="mb-1 block text-[9px] font-bold uppercase tracking-widest text-slate-500">{label}</label>
      <input
        type={type}
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value) || 0)}
        className="font-mono-data w-full rounded-md border border-white/10 bg-black/40 px-2 py-2 text-xs text-slate-200 focus:border-cyan-400/50 focus:outline-none"
      />
    </div>
  );
}
