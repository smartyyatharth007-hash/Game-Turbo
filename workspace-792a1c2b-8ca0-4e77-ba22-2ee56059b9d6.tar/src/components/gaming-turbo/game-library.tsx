"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Plus, Play, Trash2, Search, Gamepad2, X, Radar, Star, AppWindow, MonitorPlay,
} from "lucide-react";
import { AnimatePresence } from "framer-motion";
import { NeonCard, GlowTitle, NeonButton, Chip } from "./neon";
import { LaunchOverlay } from "./launch-overlay";
import { GameDetailDrawer } from "./game-detail";
import { ScanWizard } from "./scan-wizard";
import { useTurboStore, GAME_GRADIENTS } from "@/lib/store";
import { sound } from "@/lib/sound-engine";
import { useHydrated } from "@/hooks/use-hydration";
import { useToast } from "@/hooks/use-toast";
import type { Platform, TurboGame } from "@/lib/types";

const PLATFORMS: Platform[] = ["PC", "Steam", "Epic", "Xbox", "PlayStation", "Battle.net", "Mobile", "Other"];
const FPS_TARGETS = [60, 90, 120, 144, 165, 240];

export function GameLibrary() {
  const games = useTurboStore((s) => s.games);
  const addGame = useTurboStore((s) => s.addGame);
  const removeGame = useTurboStore((s) => s.removeGame);
  const detectedApps = useTurboStore((s) => s.detectedApps);
  const removeDetectedApp = useTurboStore((s) => s.removeDetectedApp);
  const pinnedId = useTurboStore((s) => s.pinnedId);
  const setPinned = useTurboStore((s) => s.setPinned);
  const startSession = useTurboStore((s) => s.startSession);
  const { toast } = useToast();

  const [launching, setLaunching] = useState<TurboGame | null>(null);
  const [detailGame, setDetailGame] = useState<TurboGame | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [scanOpen, setScanOpen] = useState(false);
  const [query, setQuery] = useState("");
  const mounted = useHydrated();

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return mounted
      ? games.filter((g) => !q || g.name.toLowerCase().includes(q) || g.genre.toLowerCase().includes(q))
      : [];
  }, [games, query, mounted]);

  const launchWithSession = (g: TurboGame) => {
    const started = startSession(g.id, g.name);
    setDetailGame(null);
    setLaunching(g);
    if (started) {
      toast({
        title: "Turbo session started",
        description: "DND + Notification Shield engaged. Extras were disabled — they restore automatically when you end the session.",
      });
    }
  };

  return (
    <div className="space-y-4">
      <NeonCard className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <GlowTitle color="magenta">Game Library</GlowTitle>
          <p className="mt-1 text-xs text-slate-500">
            Your games, auto-detected titles and pinned Turbo targets. Click a card for full details.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search games..."
              aria-label="Search games"
              className="w-40 rounded-md border border-white/10 bg-black/40 py-2 pl-8 pr-3 text-xs text-slate-200 placeholder:text-slate-600 focus:border-cyan-400/50 focus:outline-none"
            />
          </div>
          <NeonButton variant="lime" onClick={() => setScanOpen(true)}>
            <Radar className="h-3.5 w-3.5" /> Scan my PC
          </NeonButton>
          <NeonButton variant="magenta" onClick={() => setDialogOpen(true)}>
            <Plus className="h-3.5 w-3.5" /> Add Game
          </NeonButton>
        </div>
      </NeonCard>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {filtered.map((g, i) => (
          <motion.div key={g.id} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i * 0.04, 0.3) }}>
            <NeonCard className="group relative flex flex-col p-0">
              <div
                className="relative flex h-24 cursor-pointer items-center justify-between overflow-hidden rounded-t-xl px-5"
                style={{
                  background: `linear-gradient(120deg, ${g.gradient[0]}26, ${g.gradient[1]}0d)`,
                  borderBottom: `1px solid ${g.gradient[0]}33`,
                }}
                onClick={() => {
                  sound.click();
                  setDetailGame(g);
                }}
                role="button"
                aria-label={`Open details for ${g.name}`}
              >
                <div
                  className="font-display flex h-14 w-14 items-center justify-center rounded-xl text-xl font-black text-black/85 shadow-lg"
                  style={{
                    background: `linear-gradient(135deg, ${g.gradient[0]}, ${g.gradient[1]})`,
                    boxShadow: `0 0 24px ${g.gradient[0]}55`,
                  }}
                >
                  {g.name.split(/[\s:]+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase()}
                </div>
                <div className="flex flex-col items-end gap-1.5">
                  <Chip color="slate">{g.platform}</Chip>
                  {g.isCustom && <Chip color="magenta">CUSTOM</Chip>}
                  {pinnedId === g.id && <Chip color="amber">MY TURBO</Chip>}
                </div>
                {g.isCustom && (
                  <button
                    aria-label={`Delete ${g.name}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      sound.error();
                      removeGame(g.id);
                    }}
                    className="absolute right-2 top-2 rounded-md border border-rose-500/40 bg-black/50 p-1.5 text-rose-300 opacity-0 transition group-hover:opacity-100 hover:bg-rose-500/20"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
              <div className="flex flex-1 flex-col gap-3 p-4">
                <button className="text-left" onClick={() => { sound.click(); setDetailGame(g); }} aria-label={`Details ${g.name}`}>
                  <h3 className="font-display truncate text-sm font-bold text-slate-100 group-hover:text-cyan-300">{g.name}</h3>
                  <p className="text-xs text-slate-500">{g.genre}</p>
                </button>
                <div className="flex flex-wrap gap-1.5">
                  <Chip color="cyan">{g.profile.fpsTarget} FPS cap</Chip>
                  <Chip color={g.profile.priority === "MAX" ? "magenta" : "slate"}>{g.profile.priority} priority</Chip>
                  {g.profile.autoDND && <Chip color="lime">Auto DND</Chip>}
                </div>
                <div className="mt-auto flex gap-2">
                  <NeonButton variant="cyan" className="flex-1" onClick={() => launchWithSession(g)}>
                    <Play className="h-3.5 w-3.5" /> Turbo Launch
                  </NeonButton>
                  <NeonButton
                    variant="ghost"
                    size="md"
                    aria-label={`Set ${g.name} as my turbo`}
                    onClick={() => {
                      const isPinned = pinnedId === g.id;
                      sound.toggle(!isPinned);
                      setPinned(isPinned ? null : g.id);
                    }}
                    className={pinnedId === g.id ? "border-amber-400/50 text-amber-300" : ""}
                  >
                    <Star className={`h-3.5 w-3.5 ${pinnedId === g.id ? "fill-amber-300 text-amber-300" : ""}`} />
                  </NeonButton>
                </div>
              </div>
            </NeonCard>
          </motion.div>
        ))}
        {mounted && filtered.length === 0 && (
          <NeonCard className="col-span-full flex flex-col items-center gap-2 p-10 text-center">
            <Gamepad2 className="h-8 w-8 text-slate-600" />
            <p className="text-sm text-slate-500">No games match your search.</p>
            <NeonButton size="sm" variant="ghost" onClick={() => setQuery("")}>Clear search</NeonButton>
          </NeonCard>
        )}
      </div>

      {/* PC Apps library (from scan) */}
      <NeonCard variant="lime" className="p-5">
        <div className="mb-3 flex items-center justify-between">
          <div>
            <GlowTitle color="lime">PC Apps Library</GlowTitle>
            <p className="mt-1 text-xs text-slate-500">
              Everything the scanner found on your machine. Assign any app as a Gaming Turbo target.
            </p>
          </div>
          <Chip color={mounted ? (detectedApps.length ? "lime" : "slate") : "slate"}>
            {mounted ? `${detectedApps.length} items` : "..."}
          </Chip>
        </div>
        {mounted && detectedApps.length === 0 ? (
          <div className="flex flex-col items-center gap-3 rounded-lg border border-dashed border-lime-400/25 bg-black/30 p-8 text-center">
            <AppWindow className="h-7 w-7 text-slate-600" />
            <p className="max-w-md text-xs leading-relaxed text-slate-500">
              Nothing scanned yet. Run <b>TurboScan.ps1</b> on your PC (via <b>Scan my PC</b> above) to
              pull in your installed games and applications automatically — or try the instant demo scan.
            </p>
            <NeonButton size="sm" variant="lime" onClick={() => setScanOpen(true)}>
              <Radar className="h-3 w-3" /> Scan my PC
            </NeonButton>
          </div>
        ) : (
          <div className="scrollbar-neon max-h-80 space-y-1.5 overflow-y-auto pr-1">
            {mounted && detectedApps.map((a) => (
              <div key={a.id} className="flex items-center gap-2 rounded-lg border border-white/[0.07] bg-black/30 px-3 py-2">
                <MonitorPlay className="h-3.5 w-3.5 shrink-0 text-lime-400" />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-xs font-semibold text-slate-200">{a.name}</div>
                  {a.path && <div className="font-mono-data truncate text-[9px] text-slate-600">{a.path}</div>}
                </div>
                <Chip color={a.type === "game" ? "magenta" : "slate"}>{a.type}</Chip>
                <button
                  aria-label={`Make ${a.name} my turbo target`}
                  onClick={() => {
                    sound.toggle(true);
                    addGame({
                      name: a.name,
                      genre: a.type === "game" ? "Detected Game" : "App",
                      platform: a.store === "Steam" ? "Steam" : a.store === "Epic" ? "Epic" : "PC",
                      gradient: GAME_GRADIENTS[Math.floor(Math.random() * GAME_GRADIENTS.length)].stops,
                      profile: { fpsTarget: 120, priority: "HIGH", autoDND: true },
                    });
                    toast({ title: "Added to Game Library", description: `${a.name} is now a Turbo target candidate.` });
                  }}
                  className="rounded-md border border-lime-400/40 bg-lime-400/10 p-1.5 text-lime-300 transition hover:bg-lime-400/25"
                  title="Promote to Game Library"
                >
                  <Plus className="h-3.5 w-3.5" />
                </button>
                <button
                  aria-label={`Remove ${a.name}`}
                  onClick={() => {
                    sound.tick();
                    removeDetectedApp(a.id);
                  }}
                  className="text-slate-600 hover:text-rose-400"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </NeonCard>

      {dialogOpen && (
        <AddGameDialog
          onClose={() => setDialogOpen(false)}
          onAdd={(g) => {
            addGame(g);
            sound.chime();
            setDialogOpen(false);
          }}
        />
      )}

      {scanOpen && (
        <ScanWizard
          onClose={() => setScanOpen(false)}
          onImported={(n) => toast({ title: "Scan imported", description: `${n} games & apps added to your libraries.` })}
        />
      )}

      <AnimatePresence>
        {detailGame && (
          <GameDetailDrawer
            game={detailGame}
            onClose={() => setDetailGame(null)}
            onLaunchSession={launchWithSession}
          />
        )}
      </AnimatePresence>

      {launching && <LaunchOverlay game={launching} onDone={() => setLaunching(null)} />}
    </div>
  );
}

function AddGameDialog({
  onClose,
  onAdd,
}: {
  onClose: () => void;
  onAdd: (g: Omit<TurboGame, "id" | "isCustom" | "createdAt">) => void;
}) {
  const [name, setName] = useState("");
  const [genre, setGenre] = useState("");
  const [platform, setPlatform] = useState<Platform>("PC");
  const [gradIdx, setGradIdx] = useState(0);
  const [fpsTarget, setFpsTarget] = useState(120);
  const [priority, setPriority] = useState<"MAX" | "HIGH" | "BALANCED">("HIGH");
  const [autoDND, setAutoDND] = useState(true);

  const valid = name.trim().length >= 2 && genre.trim().length >= 2;

  return (
    <div
      className="fixed inset-0 z-[90] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Add game"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <NeonCard className="w-full max-w-md p-6">
        <div className="mb-5 flex items-center justify-between">
          <GlowTitle color="magenta">Add Game</GlowTitle>
          <button
            aria-label="Close dialog"
            onClick={onClose}
            className="rounded-md border border-white/10 p-1.5 text-slate-400 hover:bg-white/10"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-widest text-slate-400">Game name</label>
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Rocket League"
              className="w-full rounded-md border border-white/10 bg-black/40 px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:border-cyan-400/50 focus:outline-none"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-widest text-slate-400">Genre</label>
              <input
                value={genre}
                onChange={(e) => setGenre(e.target.value)}
                placeholder="Racing"
                className="w-full rounded-md border border-white/10 bg-black/40 px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:border-cyan-400/50 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-widest text-slate-400">Platform</label>
              <select
                value={platform}
                onChange={(e) => setPlatform(e.target.value as Platform)}
                className="w-full rounded-md border border-white/10 bg-black/40 px-3 py-2 text-sm text-slate-100 focus:border-cyan-400/50 focus:outline-none"
              >
                {PLATFORMS.map((p) => (
                  <option key={p} value={p} className="bg-[#0d0d1a]">{p}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-widest text-slate-400">Neon theme</label>
            <div className="flex flex-wrap gap-2">
              {GAME_GRADIENTS.map((g, i) => (
                <button
                  key={g.label}
                  aria-label={g.label}
                  onClick={() => {
                    sound.tick();
                    setGradIdx(i);
                  }}
                  className={`h-8 w-12 rounded-md border-2 transition ${
                    gradIdx === i ? "scale-110 border-white" : "border-transparent opacity-60"
                  }`}
                  style={{ background: `linear-gradient(135deg, ${g.stops[0]}, ${g.stops[1]})` }}
                />
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-widest text-slate-400">FPS target</label>
              <select
                value={fpsTarget}
                onChange={(e) => setFpsTarget(Number(e.target.value))}
                className="w-full rounded-md border border-white/10 bg-black/40 px-3 py-2 text-sm text-slate-100 focus:border-cyan-400/50 focus:outline-none"
              >
                {FPS_TARGETS.map((f) => (
                  <option key={f} value={f} className="bg-[#0d0d1a]">{f} FPS</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-widest text-slate-400">Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as "MAX" | "HIGH" | "BALANCED")}
                className="w-full rounded-md border border-white/10 bg-black/40 px-3 py-2 text-sm text-slate-100 focus:border-cyan-400/50 focus:outline-none"
              >
                {["MAX", "HIGH", "BALANCED"].map((p) => (
                  <option key={p} value={p} className="bg-[#0d0d1a]">{p}</option>
                ))}
              </select>
            </div>
          </div>

          <button
            onClick={() => {
              sound.toggle(!autoDND);
              setAutoDND(!autoDND);
            }}
            className="flex w-full items-center justify-between rounded-md border border-white/10 bg-black/30 px-3 py-2.5"
          >
            <span className="text-xs font-semibold text-slate-300">Auto Do-Not-Disturb on launch</span>
            <span
              className={`relative h-5 w-9 rounded-full border transition ${
                autoDND
                  ? "border-lime-400/70 bg-lime-400/25 shadow-[0_0_10px_rgba(182,255,0,0.4)]"
                  : "border-white/15 bg-white/[0.06]"
              }`}
            >
              <span
                className={`absolute top-1/2 h-3.5 w-3.5 -translate-y-1/2 rounded-full transition-all ${
                  autoDND ? "left-[18px] bg-lime-300" : "left-[3px] bg-slate-400"
                }`}
              />
            </span>
          </button>

          <div className="flex gap-2 pt-1">
            <NeonButton variant="ghost" className="flex-1" onClick={onClose}>Cancel</NeonButton>
            <NeonButton
              variant="magenta"
              className="flex-1"
              disabled={!valid}
              onClick={() =>
                onAdd({
                  name: name.trim(),
                  genre: genre.trim(),
                  platform,
                  gradient: GAME_GRADIENTS[gradIdx].stops,
                  profile: { fpsTarget, priority, autoDND },
                })
              }
            >
              <Plus className="h-3.5 w-3.5" /> Add Game
            </NeonButton>
          </div>
        </div>
      </NeonCard>
    </div>
  );
}
