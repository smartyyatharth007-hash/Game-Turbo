"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Gauge, Cpu, Layers, MonitorSmartphone, MemoryStick, Laptop, Monitor, Tablet, Play, History, BatteryFull,
} from "lucide-react";
import {
  Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { NeonCard, GlowTitle, NeonButton, Chip, StatBar } from "./neon";
import { runBenchmark, detectDevice } from "@/lib/bench";
import { useTurboStore } from "@/lib/store";
import { useRealMetrics } from "@/lib/metrics";
import { useHydrated } from "@/hooks/use-hydration";
import { sound } from "@/lib/sound-engine";

const DEVICE_ICON = { Laptop: Laptop, "Desktop PC": Monitor, Tablet: Tablet, Unknown: MonitorSmartphone };

export function BenchmarkPanel() {
  const metrics = useRealMetrics();
  const benchHistory = useTurboStore((s) => s.benchHistory);
  const addBenchRecord = useTurboStore((s) => s.addBenchRecord);
  const [running, setRunning] = useState(false);
  const [stage, setStage] = useState("");
  const [pct, setPct] = useState(0);
  const [latest, setLatest] = useState<import("@/lib/bench").BenchScores | null>(null);
  const mounted = useHydrated();

  const device = useMemo(
    () => detectDevice(metrics.battery),
    [metrics.battery?.charging, metrics.battery?.level]
  );

  const chartData = useMemo(
    () =>
      mounted
        ? benchHistory.map((b, i) => ({
            i: i + 1,
            total: b.total,
            label: new Date(b.at).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
          }))
        : [],
    [benchHistory, mounted]
  );

  const start = async () => {
    setRunning(true);
    setLatest(null);
    setPct(0);
    sound.engineRev(2);
    try {
      const res = await runBenchmark((s, p) => {
        setStage(s);
        setPct(p);
      });
      setLatest(res);
      const dev = device ?? detectDevice(metrics.battery);
      addBenchRecord({
        total: res.total,
        cpuSingle: res.cpuSingle,
        cpuMulti: res.cpuMulti,
        gpu: res.gpu,
        memory: res.memory,
        deviceType: dev.type,
      });
      sound.fanfare();
    } finally {
      setRunning(false);
    }
  };

  const DevIcon = device ? DEVICE_ICON[device.type] : MonitorSmartphone;
  const grade =
    latest === null
      ? null
      : latest.total >= 80 ? "S"
        : latest.total >= 65 ? "A"
          : latest.total >= 50 ? "B"
            : latest.total >= 35 ? "C" : "D";

  return (
    <div className="space-y-4">
      {/* Device detection */}
      <div className="grid gap-4 lg:grid-cols-3">
        <NeonCard className="p-5 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <GlowTitle>Device Detection</GlowTitle>
            {device && <Chip color="cyan">{device.confidence}% confidence</Chip>}
          </div>
          <div className="flex items-center gap-5">
            <div className="animate-float-y flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl border border-cyan-400/40 bg-cyan-400/10 shadow-[0_0_28px_rgba(0,240,255,0.25)]">
              <DevIcon className="h-10 w-10 text-cyan-300" />
            </div>
            <div className="min-w-0">
              <div className="font-display text-2xl font-black uppercase tracking-wide text-slate-100">
                {device ? device.type : "Detecting..."}
              </div>
              <p className="mt-0.5 text-xs text-slate-500">{device?.formFactorNote}</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {device?.signals.slice(0, 4).map((s) => (
                  <Chip key={s} color="slate">{s}</Chip>
                ))}
              </div>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3 border-t border-white/[0.06] pt-3 sm:grid-cols-4">
            <MiniStat icon={<Cpu className="h-3.5 w-3.5 text-cyan-400" />} label="Threads" value={`${metrics.cores ?? "--"}`} />
            <MiniStat icon={<MemoryStick className="h-3.5 w-3.5 text-fuchsia-400" />} label="RAM (reported)" value={metrics.deviceMemoryGB ? `${metrics.deviceMemoryGB}+ GB` : "N/A"} />
            <MiniStat icon={<MonitorSmartphone className="h-3.5 w-3.5 text-lime-400" />} label="Display" value={metrics.screen || "--"} />
            <MiniStat icon={<BatteryFull className="h-3.5 w-3.5 text-amber-300" />} label="Battery" value={metrics.battery ? `${metrics.battery.level}%` : "none"} />
          </div>
        </NeonCard>

        {/* Run benchmark */}
        <NeonCard variant="magenta" className="flex flex-col p-5">
          <div className="mb-4 flex items-center justify-between">
            <GlowTitle color="magenta">Turbo Benchmark</GlowTitle>
            {grade && <Chip color="amber">GRADE {grade}</Chip>}
          </div>
          <div className="flex flex-1 flex-col items-center justify-center text-center">
            <div className="font-mono-data text-7xl font-black tabular-nums text-fuchsia-300 text-glow-magenta">
              {latest ? latest.total : benchHistory.at(-1)?.total ?? "--"}
            </div>
            <div className="font-display mt-1 text-[10px] font-bold uppercase tracking-[0.3em] text-slate-500">
              TurboScore {latest ? "" : "(last run)"}
            </div>
            {running && (
              <div className="mt-4 w-full">
                <StatBar label={stage || "working"} value={pct} gradient="from-fuchsia-400 to-cyan-400" />
              </div>
            )}
            <NeonButton
              variant="magenta"
              size="lg"
              className="mt-4 w-full"
              disabled={running}
              onClick={start}
            >
              <Play className="h-4 w-4" /> {running ? "Benchmarking..." : "Run Benchmark"}
            </NeonButton>
            <p className="mt-3 text-[10px] leading-relaxed text-slate-600">
              Real measurements: prime-sieve CPU tests (single + Web Workers), a WebGL pixel-shader
              stress for GPU, and an array-bandwidth memory test. ~6 seconds. Close other tabs for
              best accuracy.
            </p>
          </div>
        </NeonCard>
      </div>

      {/* Score breakdown */}
      {latest && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <NeonCard className="p-5">
            <GlowTitle className="mb-4">Score Breakdown</GlowTitle>
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              <StatBar label="CPU single-core" value={latest.cpuSingle} gradient="from-cyan-400 to-blue-500" />
              <StatBar label={`CPU multi (${latest.coresUsed} workers)`} value={latest.cpuMulti} gradient="from-cyan-400 to-fuchsia-500" />
              <StatBar label="GPU (WebGL)" value={latest.gpu} gradient="from-fuchsia-400 to-rose-500" />
              <StatBar label="Memory bandwidth" value={latest.memory} gradient="from-lime-400 to-emerald-500" />
            </div>
            <p className="font-mono-data mt-3 text-[10px] text-slate-600">
              GPU: {latest.gpuName} · completed in {(latest.durationMs / 1000).toFixed(1)}s
            </p>
          </NeonCard>
        </motion.div>
      )}

      {/* History */}
      <NeonCard variant="lime" className="p-5">
        <div className="mb-3 flex items-center justify-between">
          <GlowTitle color="lime">TurboScore History</GlowTitle>
          <Chip color="slate"><History className="h-3 w-3" /> {benchHistory.length} runs</Chip>
        </div>
        {chartData.length > 1 ? (
          <div className="h-40">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 4, right: 8, bottom: 0, left: -18 }}>
                <defs>
                  <linearGradient id="benchFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#b6ff00" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#b6ff00" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="rgba(182,255,0,0.08)" vertical={false} />
                <XAxis dataKey="label" tick={{ fill: "#5c6b8a", fontSize: 9 }} />
                <YAxis domain={[0, 100]} tick={{ fill: "#5c6b8a", fontSize: 9 }} width={34} />
                <Tooltip
                  contentStyle={{ background: "#0d0d1a", border: "1px solid rgba(182,255,0,0.3)", borderRadius: 8, fontSize: 11 }}
                  formatter={(v) => [`${v}`, "TurboScore"]}
                />
                <Area type="monotone" dataKey="total" stroke="#b6ff00" strokeWidth={2} fill="url(#benchFill)" dot={{ r: 3, fill: "#b6ff00" }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="flex h-24 items-center justify-center rounded-lg border border-lime-400/10 bg-black/30 text-[10px] uppercase tracking-widest text-slate-600">
            <Gauge className="mr-2 h-4 w-4" /> Run the benchmark twice to see your trend line
          </div>
        )}
      </NeonCard>
    </div>
  );
}

function MiniStat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-lg border border-white/[0.07] bg-black/30 px-3 py-2">
      <div className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-widest text-slate-500">
        {icon} {label}
      </div>
      <div className="font-mono-data mt-0.5 truncate text-xs font-bold text-slate-200">{value}</div>
    </div>
  );
}
