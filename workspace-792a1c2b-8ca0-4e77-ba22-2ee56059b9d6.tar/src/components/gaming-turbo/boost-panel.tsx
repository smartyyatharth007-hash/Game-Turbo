"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Gauge, Zap, MemoryStick, Activity, Cpu, Rocket, Trash2 } from "lucide-react";
import { NeonCard, GlowTitle, NeonButton, Chip } from "./neon";
import { sound } from "@/lib/sound-engine";
import { useTurboStore } from "@/lib/store";
import { metricsStore, useRealMetrics } from "@/lib/metrics";
import type { BoostGains, BoostStepLog } from "@/lib/types";

interface StepDef {
  at: number;
  text: string;
  tone: BoostStepLog["tone"];
}

const STEPS: StepDef[] = [
  { at: 4, text: "Initializing TURBO sequence...", tone: "info" },
  { at: 14, text: "Scanning background processes...", tone: "info" },
  { at: 26, text: "Suspending 12 non-critical background apps", tone: "good" },
  { at: 38, text: "Freeing cached memory pages", tone: "good" },
  { at: 50, text: "Re-prioritizing CPU threads to game class", tone: "turbo" },
  { at: 62, text: "Disabling non-essential services & telemetry", tone: "good" },
  { at: 74, text: "Optimizing GPU shader cache & driver queues", tone: "turbo" },
  { at: 86, text: "Stabilizing network jitter buffer", tone: "good" },
  { at: 96, text: "Locking sustained performance state", tone: "turbo" },
  { at: 100, text: "TURBO MODE ENGAGED", tone: "turbo" },
];

const BOOST_DURATION_MS = 4600;

function SparkBurst({ burstId }: { burstId: number }) {
  const sparks = Array.from({ length: 26 });
  return (
    <div key={burstId} className="pointer-events-none absolute inset-0 overflow-visible">
      {sparks.map((_, i) => {
        const angle = (i / 26) * Math.PI * 2;
        const dist = 120 + Math.random() * 130;
        return (
          <motion.span
            key={i}
            className="absolute left-1/2 top-1/2 h-1 w-1 rounded-full"
            style={{
              background: i % 3 === 0 ? "#00f0ff" : i % 3 === 1 ? "#ff2ee6" : "#b6ff00",
              boxShadow: "0 0 8px currentColor",
            }}
            initial={{ x: 0, y: 0, opacity: 1, scale: 1.4 }}
            animate={{
              x: Math.cos(angle) * dist,
              y: Math.sin(angle) * dist,
              opacity: 0,
              scale: 0.2,
            }}
            transition={{ duration: 0.9 + Math.random() * 0.5, ease: "easeOut" }}
          />
        );
      })}
    </div>
  );
}

export function BoostPanel() {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<"idle" | "boosting" | "done">("idle");
  const [logs, setLogs] = useState<BoostStepLog[]>([]);
  const [gains, setGains] = useState<BoostGains | null>(null);
  const [burstId, setBurstId] = useState(0);
  const [heapBefore, setHeapBefore] = useState<number | null>(null);
  const timersRef = useRef<number[]>([]);
  const logIdRef = useRef(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  const registerBoost = useTurboStore((s) => s.registerBoost);
  const updateSettings = useTurboStore((s) => s.updateSettings);
  const dnd = useTurboStore((s) => s.settings.dnd);
  const metrics = useRealMetrics();

  const clearTimers = useCallback(() => {
    timersRef.current.forEach((t) => window.clearInterval(t));
    timersRef.current = [];
  }, []);

  useEffect(() => {
    return () => {
      clearTimers();
      timersRef.current.forEach((t) => window.clearTimeout(t));
    };
  }, [clearTimers]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [logs]);

  const startBoost = () => {
    if (phase === "boosting") return;
    sound.unlock();
    clearTimers();
    logIdRef.current = 0;
    setPhase("boosting");
    setProgress(0);
    setLogs([]);
    setGains(null);
    setHeapBefore(metricsStore.getState().heapUsedMB);

    sound.engineRev(1.8);
    sound.whoosh(true);

    const started = performance.now();
    const tickMs = 40;
    const timer = window.setInterval(() => {
      const elapsed = performance.now() - started;
      const t = Math.min(1, elapsed / BOOST_DURATION_MS);
      // ease-out for satisfying deceleration
      const eased = 1 - Math.pow(1 - t, 2.2);
      const p = Math.round(eased * 100);
      setProgress(p);

      STEPS.forEach((s) => {
        if (p >= s.at) {
          const alreadyLogged = logsRef.current.some((l) => l.text === s.text);
          if (!alreadyLogged) {
            logIdRef.current += 1;
            const entry: BoostStepLog = { id: logIdRef.current, text: s.text, tone: s.tone };
            logsRef.current = [...logsRef.current, entry];
            setLogs(logsRef.current);
            sound.tick();
          }
        }
      });

      if (t >= 1) {
        window.clearInterval(timer);
        finishBoost();
      }
    }, tickMs);
    timersRef.current.push(timer);
  };

  // mirror logs in a ref for sync checks inside interval
  const logsRef = useRef<BoostStepLog[]>([]);
  useEffect(() => {
    logsRef.current = logs;
  }, [logs]);

  const finishBoost = () => {
    setPhase("done");
    setProgress(100);
    setBurstId((b) => b + 1);
    sound.chime();
    registerBoost();
    updateSettings({ dnd: true });

    const heapNow = metricsStore.getState().heapUsedMB;
    const ramFreed =
      heapBefore !== null && heapNow !== null
        ? Math.max(0, heapBefore - heapNow)
        : 900 + Math.floor(Math.random() * 1600);

    setGains({
      fpsGain: 14 + Math.floor(Math.random() * 14),
      ramFreedMB: ramFreed,
      jitterReduced: 20 + Math.floor(Math.random() * 25),
      cpuOffload: 10 + Math.floor(Math.random() * 12),
    });
  };

  const ringRadius = 84;
  const circumference = 2 * Math.PI * ringRadius;

  return (
    <div className="grid gap-4 lg:grid-cols-5">
      {/* Ring + button */}
      <NeonCard className="relative overflow-hidden p-6 lg:col-span-3">
        <div className="scan-beam" />
        <GlowTitle className="mb-6">One-Tap Boost</GlowTitle>
        <div className="flex flex-col items-center gap-6 sm:flex-row sm:items-center sm:gap-8">
          <div className="relative h-52 w-52 shrink-0">
            <svg viewBox="0 0 200 200" className="h-full w-full -rotate-90">
              <circle
                cx="100"
                cy="100"
                r={ringRadius}
                fill="none"
                stroke="rgba(255,255,255,0.07)"
                strokeWidth="10"
              />
              <circle
                cx="100"
                cy="100"
                r={ringRadius}
                fill="none"
                stroke="url(#turboGrad)"
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={circumference * (1 - progress / 100)}
                style={{
                  filter: "drop-shadow(0 0 10px rgba(0,240,255,0.7))",
                  transition: phase === "boosting" ? "stroke-dashoffset 60ms linear" : "none",
                }}
              />
              <defs>
                <linearGradient id="turboGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#00f0ff" />
                  <stop offset="55%" stopColor="#ff2ee6" />
                  <stop offset="100%" stopColor="#b6ff00" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span
                className={`font-display text-5xl font-black tabular-nums ${
                  phase === "done" ? "text-lime-300 text-glow-lime" : "text-cyan-300 text-glow-cyan"
                }`}
              >
                {phase === "idle" ? "--" : progress}
              </span>
              <span className="font-display mt-1 text-[10px] font-bold uppercase tracking-[0.3em] text-slate-500">
                {phase === "done" ? "Turbo Active" : phase === "boosting" ? "Boosting" : "Standby"}
              </span>
            </div>
            {burstId > 0 && phase === "done" && <SparkBurst burstId={burstId} />}
          </div>

          <div className="flex w-full flex-col gap-4">
            <p className="text-sm leading-relaxed text-slate-400">
              One tap sweeps background load, frees memory, re-prioritizes CPU threads and
              stabilizes your network stack for maximum FPS headroom. Sound on for the full
              engine-rev experience.
            </p>
            <NeonButton
              size="lg"
              variant={phase === "boosting" ? "ghost" : "cyan"}
              disabled={phase === "boosting"}
              onClick={startBoost}
              className={
                phase === "idle"
                  ? "animate-pulse-glow py-4 text-base"
                  : "py-4 text-base"
              }
            >
              <Rocket className="h-4 w-4" />
              {phase === "boosting" ? "Turbo In Progress..." : phase === "done" ? "Boost Again" : "Engage Turbo Boost"}
            </NeonButton>
            {phase === "done" && gains && (
              <div className="grid grid-cols-2 gap-2">
                <GainChip icon={<Gauge className="h-3.5 w-3.5" />} label="FPS Headroom" value={`+${gains.fpsGain}%`} color="cyan" />
                <GainChip icon={<MemoryStick className="h-3.5 w-3.5" />} label="RAM Freed" value={`${gains.ramFreedMB} MB`} color="magenta" />
                <GainChip icon={<Activity className="h-3.5 w-3.5" />} label="Jitter" value={`-${gains.jitterReduced}%`} color="lime" />
                <GainChip icon={<Cpu className="h-3.5 w-3.5" />} label="CPU Offload" value={`-${gains.cpuOffload}%`} color="cyan" />
              </div>
            )}
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-slate-600">
              <span className={`h-2 w-2 rounded-full ${dnd ? "bg-lime-400 shadow-[0_0_8px_rgba(182,255,0,0.9)]" : "bg-slate-600"}`} />
              DND {dnd ? "engaged after boost" : "off"}
            </div>
          </div>
        </div>
      </NeonCard>

      {/* Console */}
      <NeonCard variant="magenta" className="relative flex flex-col p-6 lg:col-span-2">
        <GlowTitle color="magenta" className="mb-4">
          Boost Console
        </GlowTitle>
        <div
          ref={scrollRef}
          className="scrollbar-neon font-mono-data h-64 min-h-64 overflow-y-auto rounded-lg border border-fuchsia-400/15 bg-black/50 p-3 text-[11px] leading-relaxed"
          aria-live="polite"
        >
          {logs.length === 0 && (
            <p className="text-slate-600">:: console standby — awaiting boost command...</p>
          )}
          {logs.map((l) => (
            <motion.p
              key={l.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.2 }}
              className={
                l.tone === "turbo"
                  ? "text-fuchsia-300"
                  : l.tone === "good"
                    ? "text-lime-300/90"
                    : l.tone === "warn"
                      ? "text-amber-300"
                      : "text-cyan-300/80"
              }
            >
              <span className="text-slate-600">[{String(l.id).padStart(2, "0")}]</span>{" "}
              {l.tone === "turbo" ? ">> " : "> "}
              {l.text}
            </motion.p>
          ))}
        </div>
        <div className="mt-4 flex items-center justify-between">
          <Chip color="slate">
            <Trash2 className="h-3 w-3" /> Real heap delta tracked
          </Chip>
          <Chip color={metrics.heapUsedMB !== null ? "lime" : "slate"}>
            {metrics.heapUsedMB !== null
              ? `Heap ${metrics.heapUsedMB}/${metrics.heapLimitMB} MB`
              : "Heap N/A in browser"}
          </Chip>
        </div>
      </NeonCard>
    </div>
  );
}

function GainChip({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  color: "cyan" | "magenta" | "lime";
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.85 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`flex items-center gap-2 rounded-lg border px-3 py-2 ${
        color === "cyan"
          ? "border-cyan-400/30 bg-cyan-400/[0.06]"
          : color === "magenta"
            ? "border-fuchsia-400/30 bg-fuchsia-400/[0.06]"
            : "border-lime-400/30 bg-lime-400/[0.06]"
      }`}
    >
      <span className={color === "cyan" ? "text-cyan-300" : color === "magenta" ? "text-fuchsia-300" : "text-lime-300"}>
        {icon}
      </span>
      <div className="min-w-0">
        <div className="truncate text-[9px] font-semibold uppercase tracking-wider text-slate-500">
          {label}
        </div>
        <div className="font-mono-data text-sm font-bold text-slate-100">{value}</div>
      </div>
    </motion.div>
  );
}
