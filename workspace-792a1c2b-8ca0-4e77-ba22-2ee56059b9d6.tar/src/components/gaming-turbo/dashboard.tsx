"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { SessionProvider } from "next-auth/react";
import {
  Rocket, Gamepad2, DatabaseBackup, SlidersHorizontal, Volume2, VolumeX, Cpu, Wifi,
  Gauge, Smartphone, Star,
} from "lucide-react";
import { sound } from "@/lib/sound-engine";
import { useTurboStore } from "@/lib/store";
import { startMetrics, useRealMetrics } from "@/lib/metrics";
import { useHydrated } from "@/hooks/use-hydration";
import { BoostPanel } from "./boost-panel";
import { PerformanceHUD } from "./performance-hud";
import { GameLibrary } from "./game-library";
import { ExtrasPanel } from "./extras-panel";
import { BackupCenter } from "./backup-center";
import { BenchmarkPanel } from "./benchmark";
import { AndroidHub } from "./android-hub";
import { SessionBar } from "./session-bar";
import { AuthButton } from "./auth-button";
import { cn } from "@/lib/utils";

type Tab = "boost" | "games" | "bench" | "android" | "backup" | "extras";

const TABS: Array<{ id: Tab; label: string; icon: React.ReactNode }> = [
  { id: "boost", label: "Boost", icon: <Rocket className="h-3.5 w-3.5" /> },
  { id: "games", label: "Games", icon: <Gamepad2 className="h-3.5 w-3.5" /> },
  { id: "bench", label: "Bench", icon: <Gauge className="h-3.5 w-3.5" /> },
  { id: "android", label: "Android", icon: <Smartphone className="h-3.5 w-3.5" /> },
  { id: "backup", label: "Win11 Backup", icon: <DatabaseBackup className="h-3.5 w-3.5" /> },
  { id: "extras", label: "Extras", icon: <SlidersHorizontal className="h-3.5 w-3.5" /> },
];

export function TurboDashboard() {
  return (
    <SessionProvider>
      <TurboDashboardInner />
    </SessionProvider>
  );
}

function TurboDashboardInner() {
  const [tab, setTab] = useState<Tab>("boost");
  const [booting, setBooting] = useState(true);
  const mounted = useHydrated();
  const muted = useTurboStore((s) => s.settings.muted);
  const updateSettings = useTurboStore((s) => s.updateSettings);
  const pinnedId = useTurboStore((s) => s.pinnedId);
  const games = useTurboStore((s) => s.games);
  const metrics = useRealMetrics();
  const pinnedGame = games.find((g) => g.id === pinnedId);

  useEffect(() => {
    startMetrics();
    const t = window.setTimeout(() => setBooting(false), 1500);
    return () => window.clearTimeout(t);
  }, []);

  useEffect(() => {
    if (mounted) sound.setMuted(muted);
  }, [muted, mounted]);

  useEffect(() => {
    const unlock = () => sound.unlock();
    window.addEventListener("pointerdown", unlock, { once: true });
    window.addEventListener("keydown", unlock, { once: true });
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
    };
  }, []);

  const switchTab = (t: Tab) => {
    if (t === tab) return;
    sound.unlock();
    sound.whoosh(t === "boost");
    setTab(t);
  };

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-[#05050a] text-slate-200">
      {/* Background FX */}
      <div className="grid-bg pointer-events-none absolute inset-0" />
      <div className="scanlines pointer-events-none fixed inset-0 z-[60] opacity-70" />
      <div className="vignette pointer-events-none fixed inset-0 z-[61]" />

      {/* Boot splash */}
      <AnimatePresence>
        {booting && (
          <motion.div
            className="fixed inset-0 z-[120] flex flex-col items-center justify-center bg-[#05050a]"
            exit={{ opacity: 0, scale: 1.04 }}
            transition={{ duration: 0.5 }}
          >
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center"
            >
              <div className="rgb-text font-display text-4xl font-black uppercase tracking-[0.2em] sm:text-6xl">
                GAMING TURBO
              </div>
              <div className="font-mono-data mt-3 text-[10px] uppercase tracking-[0.5em] text-slate-500">
                initializing turbo core...
              </div>
              <div className="mx-auto mt-6 h-1 w-56 overflow-hidden rounded-full bg-white/[0.07]">
                <motion.div
                  className="h-full bg-gradient-to-r from-cyan-400 via-fuchsia-500 to-lime-400"
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 1.2, ease: "easeInOut" }}
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-cyan-400/15 bg-[#05050a]/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="animate-float-y relative flex h-9 w-9 items-center justify-center rounded-lg border border-cyan-400/50 bg-cyan-400/10 shadow-[0_0_18px_rgba(0,240,255,0.35)]">
              <Rocket className="h-5 w-5 text-cyan-300" />
            </div>
            <div>
              <div className="rgb-text font-display text-lg font-black uppercase leading-none tracking-[0.15em]">
                Gaming Turbo
              </div>
              <div className="font-mono-data text-[9px] uppercase tracking-[0.35em] text-slate-500">
                v3.0 // performance suite
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            {pinnedGame && (
              <span className="font-display hidden items-center gap-1.5 rounded-md border border-amber-400/40 bg-amber-400/[0.07] px-2.5 py-1.5 text-[10px] font-bold text-amber-300 lg:flex">
                <Star className="h-3 w-3 fill-amber-300" />
                {pinnedGame.name.slice(0, 18)}
              </span>
            )}
            <span className="font-mono-data hidden items-center gap-1.5 rounded-md border border-white/10 bg-white/[0.03] px-2.5 py-1.5 text-[10px] text-slate-400 sm:flex">
              <Cpu className="h-3 w-3 text-cyan-400" />
              {metrics.cores ?? "--"} threads
            </span>
            <span className="font-mono-data hidden items-center gap-1.5 rounded-md border border-white/10 bg-white/[0.03] px-2.5 py-1.5 text-[10px] text-slate-400 md:flex">
              <Wifi className="h-3 w-3 text-lime-400" />
              {metrics.rtt !== null ? `${metrics.rtt} ms` : "--"}
            </span>
            <span
              className={`font-mono-data flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-[10px] font-bold ${
                metrics.fps > 55
                  ? "border-lime-400/40 text-lime-300"
                  : "border-cyan-400/40 text-cyan-300"
              }`}
            >
              {metrics.fps || "--"} FPS
            </span>
            <button
              aria-label={muted ? "Unmute sound" : "Mute sound"}
              onClick={() => {
                sound.unlock();
                const next = !muted;
                updateSettings({ muted: next });
                if (!next) {
                  sound.setMuted(false);
                  sound.click();
                }
              }}
              className="flex h-8 w-8 items-center justify-center rounded-md border border-white/10 bg-white/[0.03] text-slate-300 transition hover:border-cyan-400/40 hover:text-cyan-300"
            >
              {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </button>
            <AuthButton />
          </div>
        </div>

        {/* Tabs */}
        <nav className="scrollbar-neon mx-auto flex max-w-7xl gap-1 overflow-x-auto px-4 sm:px-6" aria-label="Main tabs">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => switchTab(t.id)}
              aria-current={tab === t.id}
              className={cn(
                "font-display relative flex items-center gap-2 whitespace-nowrap px-4 py-2.5 text-[11px] font-bold uppercase tracking-[0.2em] transition-colors",
                tab === t.id ? "text-cyan-300" : "text-slate-500 hover:text-slate-300"
              )}
            >
              {t.icon}
              {t.label}
              {tab === t.id && (
                <motion.span
                  layoutId="tab-underline"
                  className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-gradient-to-r from-cyan-400 via-fuchsia-500 to-lime-400 shadow-[0_0_10px_rgba(0,240,255,0.8)]"
                />
              )}
            </button>
          ))}
        </nav>
      </header>

      {/* Content */}
      <main className="relative z-10 mx-auto w-full max-w-7xl px-4 py-6 sm:px-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={tab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25 }}
          >
            {tab === "boost" && (
              <div className="space-y-4">
                <BoostPanel />
                <PerformanceHUD />
              </div>
            )}
            {tab === "games" && <GameLibrary />}
            {tab === "bench" && <BenchmarkPanel />}
            {tab === "android" && <AndroidHub />}
            {tab === "backup" && <BackupCenter />}
            {tab === "extras" && <ExtrasPanel />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="relative z-10 mt-auto border-t border-white/[0.06]">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-4 text-[10px] uppercase tracking-widest text-slate-600 sm:flex-row sm:px-6">
          <span>
            Gaming Turbo // <span className="text-cyan-500">performance suite</span>
          </span>
          <span className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-lime-400 shadow-[0_0_6px_rgba(182,255,0,0.9)]" />
            Turbo status: armed
            {metrics.gpu && (
              <span className="hidden text-slate-700 lg:inline">· {metrics.gpu.slice(0, 48)}</span>
            )}
          </span>
        </div>
      </footer>

      {/* Active game session bar */}
      <SessionBar />
    </div>
  );
}
