"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Zap } from "lucide-react";
import { sound } from "@/lib/sound-engine";
import { useTurboStore } from "@/lib/store";
import type { TurboGame } from "@/lib/types";

const CHECKS = [
  "Suspending background apps",
  "Freeing cached memory",
  "Applying FPS priority profile",
  "Engaging Do-Not-Disturb",
  "Network jitter stabilizer ON",
  "Turbo state locked",
];

export function LaunchOverlay({ game, onDone }: { game: TurboGame; onDone: () => void }) {
  const [phase, setPhase] = useState<0 | 1 | 2>(0);
  const [checksDone, setChecksDone] = useState(0);
  const [count, setCount] = useState(3);
  const updateSettings = useTurboStore((s) => s.updateSettings);
  const registerBoost = useTurboStore((s) => s.registerBoost);

  useEffect(() => {
    sound.unlock();
    sound.engineRev(1.6);
    const t1 = window.setTimeout(() => setPhase(1), 1500);
    return () => window.clearTimeout(t1);
  }, []);

  useEffect(() => {
    if (phase !== 1) return;
    const iv = window.setInterval(() => {
      setChecksDone((c) => {
        const next = Math.min(CHECKS.length, c + 1);
        if (next === c) return c;
        sound.tick();
        return next;
      });
    }, 260);
    const t = window.setTimeout(() => {
      window.clearInterval(iv);
      setPhase(2);
      sound.fanfare();
      registerBoost();
      if (game.profile.autoDND) updateSettings({ dnd: true });
    }, 260 * CHECKS.length + 300);
    return () => {
      window.clearInterval(iv);
      window.clearTimeout(t);
    };
  }, [phase, game, registerBoost, updateSettings]);

  useEffect(() => {
    if (phase !== 2) return;
    let c = 3;
    setCount(c);
    const iv = window.setInterval(() => {
      c -= 1;
      setCount(c);
      sound.countdown(c === 0);
      if (c <= 0) window.clearInterval(iv);
    }, 800);
    const t = window.setTimeout(onDone, 800 * 4 + 900);
    return () => {
      window.clearInterval(iv);
      window.clearTimeout(t);
    };
  }, [phase, onDone]);

  const sparks = useMemo(() => Array.from({ length: 40 }), []);

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden bg-black/95 backdrop-blur-md"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      >
        <div className="grid-bg absolute inset-0 opacity-60" />
        <div className="scanlines absolute inset-0" />

        {/* RGB sweep lines */}
        {phase !== 0 && (
          <>
            <motion.div
              className="absolute inset-x-0 h-[2px]"
              style={{ background: "linear-gradient(90deg, transparent, #00f0ff, #ff2ee6, transparent)" }}
              initial={{ top: "0%", opacity: 0 }}
              animate={{ top: ["0%", "100%"], opacity: [0, 1, 1, 0] }}
              transition={{ duration: 1.6, repeat: phase === 1 ? Infinity : 0, ease: "linear" }}
            />
            <motion.div
              className="absolute inset-y-0 w-[2px]"
              style={{ background: "linear-gradient(180deg, transparent, #ff2ee6, #00f0ff, transparent)" }}
              initial={{ left: "0%", opacity: 0 }}
              animate={{ left: ["0%", "100%"], opacity: [0, 1, 1, 0] }}
              transition={{ duration: 2.1, repeat: phase === 1 ? Infinity : 0, ease: "linear" }}
            />
          </>
        )}

        {phase === 0 && (
          <motion.div
            key="init"
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <div className="animate-glitch font-display text-2xl font-bold uppercase tracking-[0.4em] text-cyan-300 text-glow-cyan">
              INITIALIZING
            </div>
            <div className="font-display animate-flicker mt-4 text-lg font-semibold uppercase tracking-[0.25em] text-slate-400">
              {game.name}
            </div>
            <div className="mt-8 flex justify-center gap-1.5">
              {Array.from({ length: 12 }).map((_, i) => (
                <motion.span
                  key={i}
                  className="h-3 w-1 rounded-full"
                  style={{ background: i % 2 ? "#ff2ee6" : "#00f0ff" }}
                  animate={{ opacity: [0.2, 1, 0.2] }}
                  transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.07 }}
                />
              ))}
            </div>
          </motion.div>
        )}

        {phase === 1 && (
          <motion.div
            key="checks"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-[min(92vw,420px)]"
          >
            <div
              className="font-display mb-6 text-center text-sm font-bold uppercase tracking-[0.35em]"
              style={{ color: game.gradient[0] }}
            >
              TURBO PROFILE // {game.name.toUpperCase().slice(0, 24)}
            </div>
            <div className="space-y-2.5">
              {CHECKS.slice(0, checksDone).map((c, i) => (
                <motion.div
                  key={c}
                  initial={{ opacity: 0, x: -14 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="flex items-center gap-3 rounded-md border border-cyan-400/20 bg-cyan-400/[0.05] px-3 py-2"
                >
                  <span className="flex h-5 w-5 items-center justify-center rounded-full border border-lime-400/60 bg-lime-400/10">
                    <Check className="h-3 w-3 text-lime-300" />
                  </span>
                  <span className="font-mono-data text-xs text-slate-300">{c}</span>
                  <span className="ml-auto font-mono-data text-[9px] text-slate-600">
                    OK {String(i + 1).padStart(2, "0")}
                  </span>
                </motion.div>
              ))}
            </div>
            <div className="mt-6 h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
              <motion.div
                className="h-full rounded-full"
                style={{
                  background: `linear-gradient(90deg, ${game.gradient[0]}, ${game.gradient[1]})`,
                }}
                initial={{ width: "0%" }}
                animate={{ width: `${(checksDone / CHECKS.length) * 100}%` }}
                transition={{ ease: "easeOut" }}
              />
            </div>
          </motion.div>
        )}

        {phase === 2 && (
          <motion.div
            key="go"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 16 }}
            className="relative text-center"
          >
            {/* radial spark burst */}
            {sparks.map((_, i) => {
              const angle = (i / sparks.length) * Math.PI * 2;
              return (
                <motion.span
                  key={i}
                  className="absolute left-1/2 top-1/2 h-1.5 w-1.5 rounded-full"
                  style={{
                    background: i % 2 ? game.gradient[0] : game.gradient[1],
                    boxShadow: `0 0 10px ${i % 2 ? game.gradient[0] : game.gradient[1]}`,
                  }}
                  initial={{ x: 0, y: 0, opacity: 1 }}
                  animate={{
                    x: Math.cos(angle) * (180 + Math.random() * 160),
                    y: Math.sin(angle) * (180 + Math.random() * 160),
                    opacity: 0,
                  }}
                  transition={{ duration: 1.1 + Math.random() * 0.4, ease: "easeOut" }}
                />
              );
            })}
            <motion.div
              initial={{ scale: 1.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1, type: "spring", stiffness: 160, damping: 14 }}
            >
              <div className="font-display mb-2 flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-[0.5em] text-slate-400">
                <Zap className="h-4 w-4 text-amber-300" /> Turbo Launch
              </div>
              <div
                className="rgb-text font-display text-4xl font-black uppercase tracking-wider sm:text-6xl"
                style={{ animationDuration: "3s" }}
              >
                {game.name.toUpperCase().slice(0, 28)}
              </div>
              <div className="font-display mt-3 text-sm font-semibold uppercase tracking-[0.35em] text-lime-300 text-glow-lime">
                GOOD LUCK &amp; HAVE FUN
              </div>
              <div className="font-mono-data mt-6 text-5xl font-black tabular-nums text-cyan-300 text-glow-cyan">
                {count > 0 ? count : "GO"}
              </div>
              <button
                onClick={onDone}
                className="font-display mt-8 rounded-md border border-white/20 bg-white/[0.05] px-6 py-2 text-[10px] font-bold uppercase tracking-[0.3em] text-slate-300 transition hover:bg-white/10"
              >
                Enter Game
              </button>
            </motion.div>
          </motion.div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}
