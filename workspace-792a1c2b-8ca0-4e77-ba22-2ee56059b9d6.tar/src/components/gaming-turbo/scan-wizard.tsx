"use client";

import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Download, Upload, ArrowLeft, X, Radar, CheckCircle2, FileJson, Sparkles, Trash2, Plus,
} from "lucide-react";
import { NeonCard, NeonButton, Chip, GlowTitle } from "./neon";
import { useTurboStore, type DetectedApp } from "@/lib/store";
import { buildScannerScript, downloadText } from "@/lib/ps-scripts";
import { sound } from "@/lib/sound-engine";
import { fuzzyFindSpec } from "@/lib/games-db";
import { GAME_GRADIENTS } from "@/lib/store";

interface ParsedItem {
  name: string;
  type: string;
  store: string;
  path?: string;
}

export function ScanWizard({ onClose, onImported }: { onClose: () => void; onImported: (n: number) => void }) {
  const [step, setStep] = useState<1 | 2>(1);
  const [imported, setImported] = useState<DetectedApp[]>([]);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const parseItems = (raw: string): DetectedApp[] => {
    const data = JSON.parse(raw);
    const arr: ParsedItem[] = Array.isArray(data) ? data : Array.isArray(data?.items) ? data.items : [];
    if (!arr.length) throw new Error("No items found in JSON");
    return arr
      .filter((i) => i && typeof i.name === "string")
      .map((i, idx) => ({
        id: `scan-${Date.now()}-${idx}`,
        name: i.name.trim().slice(0, 60),
        type: /game|steam|epic/i.test(`${i.type} ${i.store}`) ? ("game" as const) : ("app" as const),
        store: i.store || "System",
        path: i.path,
      }));
  };

  const handleText = (raw: string) => {
    try {
      const apps = parseItems(raw);
      setImported(apps);
      setError(null);
      setStep(2);
      sound.chime();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not parse the file");
      sound.error();
    }
  };

  const demoScan = () => {
    const demo: ParsedItem[] = [
      { name: "ELDEN RING", type: "game", store: "Steam", path: "D:\\SteamLibrary\\steamapps\\common\\ELDEN RING" },
      { name: "Forza Horizon 5", type: "game", store: "Steam", path: "D:\\SteamLibrary\\steamapps\\common\\ForzaHorizon5" },
      { name: "Hades II", type: "game", store: "Steam", path: "D:\\SteamLibrary\\steamapps\\common\\Hades II" },
      { name: "Discord", type: "app", store: "System", path: "C:\\Users\\you\\AppData\\Local\\Discord" },
      { name: "OBS Studio", type: "app", store: "System", path: "C:\\Program Files\\obs-studio" },
      { name: "Spotify", type: "app", store: "System", path: "C:\\Users\\you\\AppData\\Roaming\\Spotify" },
    ];
    setImported(
      demo.map((i, idx) => ({ id: `demo-${Date.now()}-${idx}`, name: i.name, type: i.type as "game" | "app", store: i.store, path: i.path }))
    );
    setStep(2);
    sound.chime();
  };

  return (
    <div
      className="fixed inset-0 z-[94] flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Scan my PC"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <NeonCard className="w-full max-w-2xl p-6">
        <div className="mb-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {step === 2 && (
              <NeonButton variant="ghost" size="sm" onClick={() => setStep(1)}>
                <ArrowLeft className="h-3 w-3" /> Back
              </NeonButton>
            )}
            <GlowTitle color="magenta">Auto-Detect Games &amp; Apps</GlowTitle>
          </div>
          <button aria-label="Close scanner" onClick={onClose} className="rounded-md border border-white/10 p-1.5 text-slate-400 hover:bg-white/10">
            <X className="h-4 w-4" />
          </button>
        </div>

        <AnimatePresence mode="wait">
          {step === 1 ? (
            <motion.div key="s1" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }}>
              <ol className="mb-5 space-y-3">
                {[
                  { n: "01", t: "Download TurboScan.ps1", d: "A PowerShell bridge script — the browser sandbox cannot scan your drives by itself, so this trusted script does the scanning locally." },
                  { n: "02", t: "Run it as Administrator", d: "Right-click Start > Terminal (Admin) > Set-ExecutionPolicy Bypass -Scope Process > .\\TurboScan.ps1. It checks Steam manifests, Epic manifests and installed apps, then writes turbo-scan.json to your Desktop." },
                  { n: "03", t: "Import the result", d: "Drag turbo-scan.json here (or paste its content) — your games & apps appear in the library automatically." },
                ].map((s) => (
                  <li key={s.n} className="flex gap-3 rounded-lg border border-white/[0.07] bg-black/30 p-3">
                    <span className="font-display text-lg font-black text-fuchsia-400/50">{s.n}</span>
                    <div>
                      <div className="text-sm font-semibold text-slate-200">{s.t}</div>
                      <div className="mt-0.5 text-xs leading-relaxed text-slate-500">{s.d}</div>
                    </div>
                  </li>
                ))}
              </ol>
              <div
                className="mb-4 flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-fuchsia-400/30 bg-fuchsia-400/[0.03] p-6 text-center transition hover:border-fuchsia-400/60"
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  const f = e.dataTransfer.files?.[0];
                  if (!f) return;
                  const reader = new FileReader();
                  reader.onload = () => handleText(String(reader.result));
                  reader.readAsText(f);
                }}
              >
                <FileJson className="h-7 w-7 text-fuchsia-300" />
                <p className="text-xs text-slate-400">Drop turbo-scan.json here</p>
                <input
                  ref={fileRef}
                  type="file"
                  accept=".json,.txt"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (!f) return;
                    const reader = new FileReader();
                    reader.onload = () => handleText(String(reader.result));
                    reader.readAsText(f);
                  }}
                />
                <div className="flex gap-2">
                  <NeonButton size="sm" variant="ghost" onClick={() => fileRef.current?.click()}>
                    <Upload className="h-3 w-3" /> Browse file
                  </NeonButton>
                  <NeonButton size="sm" variant="magenta" onClick={() => downloadText("TurboScan.ps1", buildScannerScript())}>
                    <Download className="h-3 w-3" /> TurboScan.ps1
                  </NeonButton>
                </div>
              </div>
              {error && <p className="mb-3 text-xs text-rose-400">{error}</p>}
              <div className="flex items-center gap-2">
                <NeonButton variant="lime" className="flex-1" onClick={demoScan}>
                  <Sparkles className="h-3.5 w-3.5" /> Try instant demo scan
                </NeonButton>
                <NeonButton variant="ghost" onClick={onClose}>Cancel</NeonButton>
              </div>
            </motion.div>
          ) : (
            <motion.div key="s2" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }}>
              <div className="mb-3 flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm font-semibold text-lime-300">
                  <CheckCircle2 className="h-4 w-4" /> {imported.length} items detected
                </span>
                <Chip color="slate">review &amp; import</Chip>
              </div>
              <div className="scrollbar-neon max-h-72 space-y-1.5 overflow-y-auto pr-1">
                {imported.map((a) => (
                  <div key={a.id} className="flex items-center gap-2 rounded-lg border border-white/[0.07] bg-black/30 px-3 py-2">
                    <Radar className="h-3.5 w-3.5 shrink-0 text-cyan-400" />
                    <span className="min-w-0 flex-1 truncate text-xs text-slate-200">{a.name}</span>
                    <Chip color={a.type === "game" ? "magenta" : "slate"}>{a.type}</Chip>
                    <Chip color="cyan">{a.store}</Chip>
                    <button
                      aria-label={`Remove ${a.name}`}
                      onClick={() => {
                        sound.tick();
                        setImported((list) => list.filter((x) => x.id !== a.id));
                      }}
                      className="text-slate-600 hover:text-rose-400"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
              <div className="mt-4 flex gap-2">
                <NeonButton
                  variant="lime"
                  className="flex-1"
                  disabled={imported.length === 0}
                  onClick={() => {
                    useTurboStore.getState().addDetectedApps(imported);
                    // auto-import games into the game library too
                    const store = useTurboStore.getState();
                    imported
                      .filter((a) => a.type === "game")
                      .forEach((a) => {
                        const spec = fuzzyFindSpec(a.name);
                        store.addGame({
                          name: a.name,
                          genre: spec?.genre ?? "Detected",
                          platform: a.store === "Steam" ? "Steam" : a.store === "Epic" ? "Epic" : "PC",
                          gradient: GAME_GRADIENTS[Math.floor(Math.random() * GAME_GRADIENTS.length)].stops,
                          profile: { fpsTarget: 120, priority: "HIGH", autoDND: true },
                        });
                      });
                    sound.fanfare();
                    onImported(imported.length);
                    onClose();
                  }}
                >
                  <Plus className="h-3.5 w-3.5" /> Import to libraries
                </NeonButton>
              </div>
              <p className="mt-3 text-[10px] text-slate-600">
                Games are added to your Game Library with auto-matched details; apps go to your PC Apps library.
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </NeonCard>
    </div>
  );
}
