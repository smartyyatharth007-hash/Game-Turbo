"use client";

import { useState } from "react";
import { signIn, signOut, useSession } from "next-auth/react";
import { LogIn, LogOut, UserRound } from "lucide-react";
import { useTurboStore } from "@/lib/store";
import { sound } from "@/lib/sound-engine";

interface ProviderInfo {
  google?: { id: string };
}

export function AuthButton() {
  const { data: session, status } = useSession();
  const guestName = useTurboStore((s) => s.guestName);
  const setGuestName = useTurboStore((s) => s.setGuestName);
  const [showDialog, setShowDialog] = useState(false);
  const [nameInput, setNameInput] = useState("");

  const displayName =
    session?.user?.name ?? guestName ?? null;
  const avatarUrl = session?.user?.image ?? null;
  const initials = (displayName ?? "G")
    .split(/\s+/)
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  const handleGoogle = async () => {
    sound.click();
    try {
      const res = await fetch("/api/auth/providers");
      const providers: ProviderInfo = await res.json();
      if (providers && providers.google) {
        await signIn("google", { callbackUrl: "/" });
      } else {
        setShowDialog(true);
      }
    } catch {
      setShowDialog(true);
    }
  };

  return (
    <>
      {status === "authenticated" && session?.user ? (
        <div className="flex items-center gap-2">
          <div className="hidden items-center gap-2 rounded-md border border-lime-400/30 bg-lime-400/[0.07] px-2.5 py-1.5 sm:flex">
            {avatarUrl ? (
              <img src={avatarUrl} alt="avatar" className="h-5 w-5 rounded-full" referrerPolicy="no-referrer" />
            ) : (
              <UserRound className="h-4 w-4 text-lime-300" />
            )}
            <span className="max-w-[110px] truncate text-[11px] font-semibold text-lime-200">
              {displayName}
            </span>
          </div>
          <button
            aria-label="Sign out"
            onClick={() => {
              sound.toggle(false);
              void signOut({ callbackUrl: "/" });
            }}
            className="flex h-8 w-8 items-center justify-center rounded-md border border-white/10 bg-white/[0.03] text-slate-300 transition hover:border-rose-400/40 hover:text-rose-300"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      ) : displayName ? (
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 rounded-md border border-cyan-400/30 bg-cyan-400/[0.07] px-2.5 py-1.5">
            <span className="font-display flex h-5 w-5 items-center justify-center rounded-full bg-cyan-400/30 text-[9px] font-black text-cyan-200">
              {initials}
            </span>
            <span className="hidden max-w-[100px] truncate text-[11px] font-semibold text-cyan-200 sm:block">
              {displayName}
            </span>
          </div>
          <button
            aria-label="Reset local profile"
            onClick={() => {
              sound.toggle(false);
              setGuestName(null);
            }}
            className="flex h-8 w-8 items-center justify-center rounded-md border border-white/10 bg-white/[0.03] text-slate-300 transition hover:border-rose-400/40 hover:text-rose-300"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      ) : (
        <button
          onClick={handleGoogle}
          className="font-display flex items-center gap-2 rounded-md border border-white/15 bg-white px-3 py-1.5 text-[11px] font-bold text-slate-800 transition hover:shadow-[0_0_16px_rgba(255,255,255,0.35)]"
        >
          <GoogleG /> Sign in
        </button>
      )}

      {showDialog && (
        <div
          className="fixed inset-0 z-[95] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          onClick={(e) => e.target === e.currentTarget && setShowDialog(false)}
        >
          <div className="neon-card w-full max-w-md rounded-xl p-6">
            <h3 className="font-display text-sm font-bold uppercase tracking-[0.2em] text-cyan-300 text-glow-cyan">
              Google Sign-In Setup
            </h3>
            <p className="mt-3 text-sm leading-relaxed text-slate-400">
              Google OAuth is wired up and ready — it just needs credentials. The server checked{" "}
              <span className="font-mono-data text-cyan-300">/api/auth/providers</span> and no
              Google provider is active yet. To enable it, set these environment variables and
              reload:
            </p>
            <pre className="font-mono-data mt-3 overflow-x-auto rounded-lg border border-cyan-400/20 bg-black/60 p-3 text-[11px] text-cyan-100">
{`GOOGLE_CLIENT_ID=xxxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-xxxx
NEXTAUTH_SECRET=any-long-random-string
NEXTAUTH_URL=<this-site-url>`}
            </pre>
            <p className="mt-3 text-xs text-slate-500">
              (Get both from console.cloud.google.com &rarr; APIs &amp; Services &rarr; Credentials
              &rarr; OAuth client ID, authorized redirect URI:{" "}
              <span className="font-mono-data">{"<site>"}/api/auth/callback/google</span>)
            </p>
            <div className="mt-4 border-t border-white/10 pt-4">
              <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-widest text-slate-400">
                Or continue with a local profile
              </label>
              <div className="flex gap-2">
                <input
                  value={nameInput}
                  onChange={(e) => setNameInput(e.target.value)}
                  placeholder="Your gamer name"
                  className="flex-1 rounded-md border border-white/10 bg-black/40 px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:border-cyan-400/50 focus:outline-none"
                />
                <button
                  onClick={() => {
                    if (nameInput.trim().length < 2) return;
                    sound.chime();
                    setGuestName(nameInput.trim());
                    setShowDialog(false);
                  }}
                  className="font-display rounded-md border border-cyan-400/60 bg-cyan-400/10 px-4 py-2 text-[11px] font-bold uppercase tracking-widest text-cyan-200 hover:bg-cyan-400/25"
                >
                  Continue
                </button>
              </div>
            </div>
            <button
              onClick={() => setShowDialog(false)}
              className="font-display mt-4 w-full rounded-md border border-white/10 bg-white/[0.04] py-2 text-[10px] font-bold uppercase tracking-[0.25em] text-slate-400 hover:bg-white/10"
            >
              Back
            </button>
          </div>
        </div>
      )}
    </>
  );
}

function GoogleG() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden>
      <path fill="#4285F4" d="M23.5 12.3c0-.9-.1-1.5-.3-2.2H12v4.1h6.6c-.1 1.1-.8 2.7-2.4 3.8l3.7 2.9c2.3-2.1 3.6-5.2 3.6-8.6z" />
      <path fill="#34A853" d="M12 24c3.2 0 5.9-1.1 7.9-2.9l-3.7-2.9c-1 .7-2.4 1.2-4.2 1.2-3.2 0-5.9-2.1-6.9-5l-3.9 3C3.2 21.3 7.3 24 12 24z" />
      <path fill="#FBBC05" d="M5.1 14.4c-.3-.7-.4-1.5-.4-2.4s.2-1.7.4-2.4l-3.9-3C.4 8.2 0 10 0 12s.4 3.8 1.2 5.4l3.9-3z" />
      <path fill="#EA4335" d="M12 4.7c1.8 0 3 .8 3.7 1.4l3.3-3.2C17.9 1.1 15.2 0 12 0 7.3 0 3.2 2.7 1.2 6.6l3.9 3c1-2.9 3.7-4.9 6.9-4.9z" />
    </svg>
  );
}
