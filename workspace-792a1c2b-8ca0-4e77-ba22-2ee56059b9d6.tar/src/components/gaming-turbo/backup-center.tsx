"use client";

import { useMemo, useState } from "react";
import {
  HardDrive,
  Copy,
  Download,
  ArrowRight,
  ShieldCheck,
  TerminalSquare,
  Info,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";
import { NeonCard, GlowTitle, NeonButton, Chip } from "./neon";
import { sound } from "@/lib/sound-engine";

const TARGET_DRIVES = ["E:", "F:", "G:", "H:", "I:", "D:"];

interface Options {
  target: string;
  systemState: boolean;
  userFolders: boolean;
  restorePoint: boolean;
  verify: boolean;
}

function buildScript(o: Options): string {
  const lines: string[] = [];
  lines.push("==============================================================");
  lines.push(" GAMING TURBO  //  WINDOWS 11 FULL SYSTEM BACKUP");
  lines.push(" Duplicates your entire operating system to another disk.");
  lines.push(" HOW TO RUN:  Right-click Start > Terminal (Admin) or");
  lines.push("              PowerShell (Admin), then run this file:");
  lines.push("              Set-ExecutionPolicy Bypass -Scope Process;");
  lines.push("              .\\TurboBackup.ps1");
  lines.push("==============================================================");
  lines.push("");
  lines.push("# ---- CONFIG (edit here if your letters differ) ----");
  lines.push(`$Target = "${o.target}"        # destination disk root`);
  lines.push('');
  lines.push('# 0) Sanity checks');
  lines.push('if (-not (Test-Path $Target)) {');
  lines.push('    Write-Host "Target drive $Target not found!" -ForegroundColor Red');
  lines.push('    exit 1');
  lines.push('}');
  lines.push('Write-Host ">> Target disk ready: $Target" -ForegroundColor Cyan');
  lines.push("");
  if (o.restorePoint) {
    lines.push("# 1) Create a restore point first (safety snapshot)");
    lines.push(
      "Checkpoint-Computer -Description 'TurboBackup pre-image' -RestorePointType MODIFY_SETTINGS"
    );
    lines.push('Write-Host ">> Restore point created" -ForegroundColor Green');
    lines.push("");
  }
  lines.push("# 2) FULL SYSTEM IMAGE - copies the whole OS volume(s).");
  lines.push("#    -include:C:          -> your Windows drive");
  lines.push("#    -allCritical         -> includes boot + system reserved partitions");
  lines.push("#    -systemState         -> OS registry + boot files");
  lines.push("#    -vssFull             -> volume snapshot, apps keep running");
  lines.push("wbadmin start backup `");
  lines.push("  -backupTarget:$Target `");
  lines.push("  -include:C: `");
  lines.push("  -allCritical `");
  if (o.systemState) lines.push("  -systemState `");
  lines.push("  -vssFull `");
  lines.push("  -quiet");
  lines.push('Write-Host ">> System image written to $Target\\WindowsImageBackup" -ForegroundColor Green');
  lines.push("");
  if (o.userFolders) {
    lines.push("# 3) FILE-LEVEL MIRROR of your user profile (optional extra copy)");
    lines.push("#    /MIR mirrors; /XJ skips junctions (avoids loops); /COPYALL keeps ACLs");
    lines.push(
      "robocopy C:\\Users \"$Target\\TurboBackup\\Users\" /MIR /COPYALL /R:1 /W:1 /XJ /FFT /NP"
    );
    lines.push('Write-Host ">> User profile mirrored to $Target\\TurboBackup\\Users" -ForegroundColor Green');
    lines.push("");
  }
  if (o.verify) {
    lines.push("# 4) VERIFY - list the backup versions stored on the target");
    lines.push(`wbadmin get versions -backupTarget:${o.target}`);
    lines.push('Write-Host ">> Verify done - a version should be listed above" -ForegroundColor Green');
    lines.push("");
  }
  lines.push("# -------------------------------------------------------------");
  lines.push("# RESTORE LATER (when Windows is broken):");
  lines.push("#   Boot from Windows 11 install USB > Repair your computer >");
  lines.push("#   Troubleshoot > System Image Recovery > point at");
  lines.push(`#   ${o.target}\\WindowsImageBackup`);
  lines.push("# -------------------------------------------------------------");
  lines.push('Write-Host ">> TURBO BACKUP COMPLETE. GG." -ForegroundColor Cyan');
  return lines.join("\n");
}

export function BackupCenter() {
  const [opts, setOpts] = useState<Options>({
    target: "E:",
    systemState: true,
    userFolders: true,
    restorePoint: true,
    verify: true,
  });
  const [copied, setCopied] = useState(false);

  const script = useMemo(() => buildScript(opts), [opts]);

  const copyScript = async () => {
    try {
      await navigator.clipboard.writeText(script);
      setCopied(true);
      sound.chime();
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      sound.error();
    }
  };

  const downloadScript = () => {
    const blob = new Blob([script], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "TurboBackup.ps1";
    a.click();
    URL.revokeObjectURL(url);
    sound.whoosh(true);
  };

  return (
    <div className="space-y-4">
      {/* Hero explanation */}
      <NeonCard className="relative overflow-hidden p-6">
        <div className="scan-beam" />
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <GlowTitle color="cyan">Turbo Backup Center</GlowTitle>
            <h3 className="font-display mt-2 text-xl font-black uppercase tracking-wide text-slate-100">
              Duplicate Windows 11 to another disk
            </h3>
          </div>
          <Chip color="cyan">
            <ShieldCheck className="h-3 w-3" /> Full OS image
          </Chip>
        </div>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-slate-400">
          A browser cannot clone disks by itself — so this center does the next best thing: it
          builds a ready-to-run <span className="text-cyan-300">PowerShell script</span> using{" "}
          <span className="font-mono-data text-cyan-300">wbadmin</span> (built into Windows 11) that
          copies your <span className="text-slate-200">entire operating system — boot files, system
          partitions, programs and settings</span> — onto another disk as a full system image. Pick
          your target drive, download, run as Administrator, done.
        </p>
      </NeonCard>

      <div className="grid gap-4 lg:grid-cols-5">
        {/* Config */}
        <NeonCard variant="lime" className="p-5 lg:col-span-2">
          <GlowTitle color="lime" className="mb-4">
            Backup Options
          </GlowTitle>

          {/* Drive flow */}
          <div className="mb-5 flex items-center justify-center gap-3">
            <DriveBadge letter="C:" label="OS source" sub="Windows 11" />
            <ArrowRight className="h-5 w-5 text-lime-300" />
            <div>
              <label
                htmlFor="target-drive"
                className="mb-1 block text-[9px] font-bold uppercase tracking-widest text-slate-500"
              >
                Target disk
              </label>
              <select
                id="target-drive"
                value={opts.target}
                onChange={(e) => {
                  sound.tick();
                  setOpts((o) => ({ ...o, target: e.target.value }));
                }}
                className="rounded-md border border-lime-400/40 bg-black/50 px-3 py-2 font-mono-data text-sm font-bold text-lime-200 focus:border-lime-400 focus:outline-none"
              >
                {TARGET_DRIVES.map((d) => (
                  <option key={d} value={d} className="bg-[#0d0d1a]">
                    {d}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-2.5">
            <CheckRow
              checked={opts.systemState}
              onChange={(v) => setOpts((o) => ({ ...o, systemState: v }))}
              label="Include system state"
              desc="Registry, boot files, COM+ class db"
            />
            <CheckRow
              checked={opts.userFolders}
              onChange={(v) => setOpts((o) => ({ ...o, userFolders: v }))}
              label="Mirror user profile (robocopy)"
              desc="Extra file-level copy of C:\Users with permissions"
            />
            <CheckRow
              checked={opts.restorePoint}
              onChange={(v) => setOpts((o) => ({ ...o, restorePoint: v }))}
              label="Create restore point first"
              desc="Safety snapshot before imaging"
            />
            <CheckRow
              checked={opts.verify}
              onChange={(v) => setOpts((o) => ({ ...o, verify: v }))}
              label="Verify after backup"
              desc="List image versions on the target disk"
            />
          </div>

          <div className="mt-5 flex gap-2">
            <NeonButton variant="lime" className="flex-1" onClick={copyScript}>
              {copied ? <CheckCircle2 className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              {copied ? "Copied!" : "Copy Script"}
            </NeonButton>
            <NeonButton variant="cyan" className="flex-1" onClick={downloadScript}>
              <Download className="h-4 w-4" /> TurboBackup.ps1
            </NeonButton>
          </div>

          <div className="mt-4 flex gap-2 rounded-lg border border-amber-400/25 bg-amber-400/[0.06] p-3">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300" />
            <p className="text-[11px] leading-relaxed text-amber-200/90">
              Target disk must have <b>free space ≥ used space on C:</b>. The backup runs inside
              Windows while you keep working (VSS snapshot). Keep the target disk connected.
            </p>
          </div>
        </NeonCard>

        {/* Script preview */}
        <NeonCard className="p-5 lg:col-span-3">
          <div className="mb-3 flex items-center justify-between">
            <GlowTitle color="cyan">Generated Script Preview</GlowTitle>
            <Chip color="slate">
              <TerminalSquare className="h-3 w-3" /> PowerShell · Admin
            </Chip>
          </div>
          <pre className="scrollbar-neon font-mono-data max-h-[420px] overflow-auto rounded-lg border border-cyan-400/15 bg-black/60 p-4 text-[11px] leading-relaxed text-cyan-100/90">
            {script}
          </pre>
        </NeonCard>
      </div>

      {/* Steps */}
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <StepCard
          n="01"
          title="Connect target disk"
          body="Plug in (or pick) the spare internal/USB disk, ideally NTFS-formatted, with free space ≥ the used space on your C: drive."
        />
        <StepCard
          n="02"
          title="Run as Administrator"
          body="Right-click Start > Terminal (Admin). Allow script execution for this window: Set-ExecutionPolicy Bypass -Scope Process, then .\\TurboBackup.ps1"
        />
        <StepCard
          n="03"
          title="Let it image"
          body="wbadmin snapshots C: (and boot partitions) and writes the full image to the target disk. Progress prints in the terminal; no reboot needed."
        />
        <StepCard
          n="04"
          title="Restore anytime"
          body="Boot from a Windows 11 install USB > Repair your computer > System Image Recovery and select the WindowsImageBackup folder."
        />
      </div>

      <NeonCard variant="magenta" className="p-5">
        <div className="flex gap-3">
          <Info className="mt-0.5 h-5 w-5 shrink-0 text-fuchsia-300" />
          <div>
            <GlowTitle color="magenta" className="mb-2">
              Want a bootable 1:1 clone instead?
            </GlowTitle>
            <p className="text-sm leading-relaxed text-slate-400">
              A <b>wbadmin image</b> restores via Windows Recovery — perfect for disaster recovery.
              If you want the other disk to be an instantly-bootable duplicate (swap the disk and
              go), use a dedicated sector-cloning tool after generating your plan here:
              <span className="text-slate-200"> Macrium Reflect Free</span>,{" "}
              <span className="text-slate-200">DiskGenius</span>, or{" "}
              <span className="text-slate-200">Clonezilla</span> — all do disk-to-disk clones of
              Windows 11 with the same flow: pick source disk, pick destination disk, clone, keep
              only one disk connected at first boot.
            </p>
          </div>
        </div>
      </NeonCard>
    </div>
  );
}

function DriveBadge({ letter, label, sub }: { letter: string; label: string; sub: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className="flex h-12 w-12 items-center justify-center rounded-lg border border-cyan-400/40 bg-cyan-400/10 shadow-[0_0_16px_rgba(0,240,255,0.25)]">
        <HardDrive className="h-6 w-6 text-cyan-300" />
      </div>
      <div>
        <div className="font-mono-data text-sm font-bold text-slate-100">{letter}</div>
        <div className="text-[9px] uppercase tracking-widest text-slate-500">{label}</div>
        <div className="text-[9px] text-slate-600">{sub}</div>
      </div>
    </div>
  );
}

function CheckRow({
  checked,
  onChange,
  label,
  desc,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  desc: string;
}) {
  return (
    <button
      role="checkbox"
      aria-checked={checked}
      aria-label={label}
      onClick={() => {
        sound.toggle(!checked);
        onChange(!checked);
      }}
      className="flex w-full items-start gap-3 rounded-lg border border-white/[0.07] bg-black/30 p-3 text-left transition hover:border-lime-400/30"
    >
      <span
        className={`mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border transition ${
          checked
            ? "border-lime-400 bg-lime-400/30 text-lime-200"
            : "border-white/20 bg-transparent"
        }`}
      >
        {checked && <CheckCircle2 className="h-3 w-3" />}
      </span>
      <span>
        <span className="block text-xs font-semibold text-slate-200">{label}</span>
        <span className="block text-[10px] text-slate-500">{desc}</span>
      </span>
    </button>
  );
}

function StepCard({ n, title, body }: { n: string; title: string; body: string }) {
  return (
    <NeonCard className="p-5">
      <div className="font-display text-2xl font-black text-cyan-400/40">{n}</div>
      <h4 className="font-display mt-1 text-sm font-bold uppercase tracking-wider text-slate-100">
        {title}
      </h4>
      <p className="mt-2 text-xs leading-relaxed text-slate-500">{body}</p>
    </NeonCard>
  );
}
