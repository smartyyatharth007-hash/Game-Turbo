"use client";

import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Smartphone, UploadCloud, Cpu, Layers, HardDrive, Puzzle, Plus, Download, Info, X,
} from "lucide-react";
import { NeonCard, GlowTitle, NeonButton, Chip } from "./neon";
import { analyzeApk, type ApkAnalysis } from "@/lib/apk";
import { buildApkInstallScript, downloadText } from "@/lib/ps-scripts";
import { useTurboStore, GAME_GRADIENTS } from "@/lib/store";
import { sound } from "@/lib/sound-engine";

export function AndroidHub() {
  const [analysis, setAnalysis] = useState<ApkAnalysis | null>(null);
  const [busy, setBusy] = useState(false);
  const [drag, setDrag] = useState(false);
  const [added, setAdded] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const addGame = useTurboStore((s) => s.addGame);

  const handleFile = async (file: File) => {
    if (!file.name.toLowerCase().endsWith(".apk")) {
      sound.error();
      setAnalysis({
        valid: false, fileName: file.name, fileSizeMB: 0, entryCount: 0, dexCount: 0, abis: [],
        engine: "-", isGame: false, hasManifest: false, biggestAssets: [], totalUncompressedMB: 0,
        note: "Only .apk files can be analyzed here.",
      });
      return;
    }
    setBusy(true);
    sound.whoosh(true);
    try {
      const result = await analyzeApk(file);
      setAnalysis(result);
      setAdded(false);
      if (result.valid) sound.chime();
      else sound.error();
    } catch {
      sound.error();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <NeonCard className="relative overflow-hidden p-6">
        <div className="scan-beam" />
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <GlowTitle color="lime">Android Hub</GlowTitle>
            <h3 className="font-display mt-2 text-xl font-black uppercase tracking-wide text-slate-100">
              Run .apk games on your machine
            </h3>
          </div>
          <Chip color="lime">WSA / ADB bridge</Chip>
        </div>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-slate-400">
          Drop any <span className="font-mono-data text-lime-300">.apk</span> below — Gaming Turbo
          reads its structure right in your browser (no upload): package size, native ABIs, and a
          game-engine fingerprint. Then grab a ready-made ADB install script for Windows Subsystem
          for Android or your emulator.
        </p>
      </NeonCard>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Drop zone */}
        <NeonCard variant="lime" className="p-5">
          <GlowTitle color="lime" className="mb-4">APK Analyzer</GlowTitle>
          <div
            className={`flex flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed p-10 text-center transition ${
              drag ? "border-lime-400 bg-lime-400/10" : "border-lime-400/30 bg-black/30 hover:border-lime-400/60"
            }`}
            onDragOver={(e) => {
              e.preventDefault();
              setDrag(true);
            }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDrag(false);
              const f = e.dataTransfer.files?.[0];
              if (f) void handleFile(f);
            }}
          >
            {busy ? (
              <motion.div
                className="h-10 w-10 rounded-full border-2 border-lime-400 border-t-transparent"
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 0.8, ease: "linear" }}
              />
            ) : (
              <UploadCloud className="h-10 w-10 text-lime-300" />
            )}
            <p className="text-sm text-slate-300">{busy ? "Parsing APK structure..." : "Drop your .apk here"}</p>
            <p className="text-[10px] uppercase tracking-widest text-slate-600">
              Parsed locally — file never leaves your browser
            </p>
            <input
              ref={inputRef}
              type="file"
              accept=".apk,application/vnd.android.package-archive"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) void handleFile(f);
              }}
            />
            <NeonButton size="sm" variant="lime" onClick={() => inputRef.current?.click()}>
              Browse file
            </NeonButton>
          </div>
        </NeonCard>

        {/* Analysis result */}
        <NeonCard className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <GlowTitle>Analysis Report</GlowTitle>
            {analysis && (
              <button aria-label="Clear analysis" onClick={() => setAnalysis(null)} className="rounded-md border border-white/10 p-1.5 text-slate-400 hover:bg-white/10">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          {!analysis ? (
            <div className="flex h-64 flex-col items-center justify-center gap-2 rounded-lg border border-white/[0.07] bg-black/30 text-center">
              <Smartphone className="h-7 w-7 text-slate-600" />
              <p className="max-w-[220px] text-xs text-slate-600">
                Analysis report will appear here after you drop an APK.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-xs font-bold ${
                analysis.valid ? "border-lime-400/40 bg-lime-400/[0.07] text-lime-300" : "border-rose-400/40 bg-rose-400/[0.07] text-rose-300"
              }`}>
                {analysis.valid ? <Info className="h-4 w-4" /> : <X className="h-4 w-4" />}
                {analysis.note}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Stat icon={<HardDrive className="h-3.5 w-3.5" />} label="APK size" value={`${analysis.fileSizeMB} MB`} />
                <Stat icon={<Layers className="h-3.5 w-3.5" />} label="Entries" value={`${analysis.entryCount}`} />
                <Stat icon={<Cpu className="h-3.5 w-3.5" />} label="Native ABIs" value={analysis.abis.length ? analysis.abis.join(", ") : "none (managed)"} />
                <Stat icon={<Puzzle className="h-3.5 w-3.5" />} label="Engine" value={analysis.engine} />
              </div>
              {analysis.biggestAssets.length > 0 && (
                <div className="rounded-lg border border-white/[0.07] bg-black/40 p-3">
                  <div className="mb-1.5 text-[9px] font-bold uppercase tracking-widest text-slate-500">
                    Largest contents
                  </div>
                  {analysis.biggestAssets.map((e) => (
                    <div key={e.name} className="flex items-baseline justify-between gap-2 py-0.5">
                      <span className="font-mono-data truncate text-[10px] text-slate-400">{e.name}</span>
                      <span className="font-mono-data shrink-0 text-[10px] text-slate-500">{(e.size / 1048576).toFixed(1)} MB</span>
                    </div>
                  ))}
                </div>
              )}
              <AnimatePresence>
                {analysis.valid && (
                  <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="grid grid-cols-2 gap-2">
                    <NeonButton
                      variant="lime"
                      disabled={added}
                      onClick={() => {
                        addGame({
                          name: analysis.fileName.replace(/\.apk$/i, "").replace(/[._]/g, " "),
                          genre: analysis.isGame ? "Android Game" : "Android App",
                          platform: "Mobile",
                          gradient: GAME_GRADIENTS[Math.floor(Math.random() * GAME_GRADIENTS.length)].stops,
                          profile: { fpsTarget: 60, priority: "HIGH", autoDND: true },
                        });
                        setAdded(true);
                        sound.chime();
                      }}
                    >
                      <Plus className="h-3.5 w-3.5" /> {added ? "In Library" : "Add to Library"}
                    </NeonButton>
                    <NeonButton
                      variant="cyan"
                      onClick={() => downloadText("TurboApkInstall.ps1", buildApkInstallScript(`C:\\Users\\you\\Downloads\\${analysis.fileName}`))}
                    >
                      <Download className="h-3.5 w-3.5" /> Install Script
                    </NeonButton>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
        </NeonCard>
      </div>

      <NeonCard variant="magenta" className="p-5">
        <GlowTitle color="magenta" className="mb-2">How to actually run APKs on Windows 11</GlowTitle>
        <ol className="space-y-2 text-xs leading-relaxed text-slate-400">
          <li><b className="text-slate-200">1. Windows Subsystem for Android</b> (official): install from Microsoft Store, open WSA settings &rarr; Advanced &rarr; Developer mode, then use the generated script — it runs <span className="font-mono-data text-lime-300">adb connect 127.0.0.1:58526</span> and <span className="font-mono-data text-lime-300">adb install -r</span>.</li>
          <li><b className="text-slate-200">2. Emulator</b> (BlueStacks / LDPlayer / MuMu): enable ADB in emulator settings, then run the same script with its port.</li>
          <li><b className="text-slate-200">3. Play testing</b>: installed APKs appear in Start and can be pinned — add them to your Gaming Turbo library and launch them like any other game.</li>
        </ol>
      </NeonCard>
    </div>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-lg border border-white/[0.07] bg-black/30 px-3 py-2">
      <div className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-widest text-slate-500">
        {icon} {label}
      </div>
      <div className="font-mono-data mt-0.5 truncate text-sm font-bold text-slate-200">{value}</div>
    </div>
  );
}
