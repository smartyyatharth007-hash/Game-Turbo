import { TurboDashboard } from "@/components/gaming-turbo/dashboard";

export default function Home() {
  return <TurboDashboard />;
}
