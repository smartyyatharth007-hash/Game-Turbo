/**
 * Turbo Benchmark — real, in-browser performance measurements.
 * CPU single/multi (prime sieve), GPU (WebGL pixel workload), memory (copy bandwidth).
 * Also: honest device-type detection (laptop vs desktop vs tablet).
 */

export interface BenchScores {
  cpuSingle: number; // 0..100
  cpuMulti: number; // 0..100
  gpu: number; // 0..100
  memory: number; // 0..100
  total: number; // 0..100 composite
  coresUsed: number;
  gpuName: string;
  durationMs: number;
}

export interface DeviceProfile {
  type: "Laptop" | "Desktop PC" | "Tablet" | "Unknown";
  confidence: number; // 0..100
  signals: string[];
  formFactorNote: string;
}

function sievePrimes(limit: number): number {
  const n = limit;
  const composite = new Uint8Array(n + 1);
  let count = 0;
  for (let i = 2; i <= n; i++) {
    if (!composite[i]) {
      count++;
      for (let j = i * i; j <= n; j += i) composite[j] = 1;
    }
  }
  return count;
}

function cpuSingleTest(): { ms: number; primes: number } {
  const t0 = performance.now();
  const primes = sievePrimes(200000);
  return { ms: performance.now() - t0, primes };
}

async function cpuMultiTest(cores: number): Promise<number> {
  const n = Math.min(16, Math.max(2, cores));
  const workers = await Promise.all(
    Array.from({ length: n }, () => {
      const src = `self.onmessage=()=>{const n=150000;const c=new Uint8Array(n+1);let k=0;for(let i=2;i<=n;i++){if(!c[i]){k++;for(let j=i*i;j<=n;j+=i)c[j]=1;}}postMessage(k);};`;
      const url = URL.createObjectURL(new Blob([src], { type: "text/javascript" }));
      const w = new Worker(url);
      URL.revokeObjectURL(url);
      return new Promise<number>((res) => {
        w.onmessage = (e) => {
          res(e.data);
          w.terminate();
        };
        w.postMessage(0);
      });
    })
  );
  void workers;
  const t0 = performance.now();
  await Promise.all(
    Array.from({ length: n }, () => {
      const src = `self.onmessage=()=>{const n=150000;const c=new Uint8Array(n+1);let k=0;for(let i=2;i<=n;i++){if(!c[i]){k++;for(let j=i*i;j<=n;j+=i)c[j]=1;}}postMessage(k);};`;
      const url = URL.createObjectURL(new Blob([src], { type: "text/javascript" }));
      const w = new Worker(url);
      URL.revokeObjectURL(url);
      return new Promise<number>((res) => {
        w.onmessage = (e) => {
          res(e.data);
          w.terminate();
        };
        w.postMessage(0);
      });
    })
  );
  return performance.now() - t0;
}

function gpuTest(): Promise<{ fps: number; name: string }> {
  return new Promise((resolve) => {
    const canvas = document.createElement("canvas");
    canvas.width = 640;
    canvas.height = 480;
    const gl = canvas.getContext("webgl", { antialias: false });
    if (!gl) {
      resolve({ fps: 0, name: "WebGL unavailable" });
      return;
    }
    const dbg = gl.getExtension("WEBGL_debug_renderer_info");
    const name = dbg
      ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL))
      : String(gl.getParameter(gl.RENDERER));

    const vs = `attribute vec2 p;void main(){gl_Position=vec4(p,0.0,1.0);}`;
    const fs = `precision mediump float;uniform float t;void main(){
      vec2 uv=gl_FragCoord.xy/640.0;
      float v=sin(uv.x*40.0+t)*cos(uv.y*40.0-t)+sin(length(uv-0.5)*60.0);
      gl_FragColor=vec4(0.5+0.5*sin(v), 0.2, 0.5, 1.0);}`;
    const compile = (type: number, src: string) => {
      const s = gl.createShader(type)!;
      gl.shaderSource(s, src);
      gl.compileShader(s);
      return s;
    };
    const prog = gl.createProgram()!;
    gl.attachShader(prog, compile(gl.VERTEX_SHADER, vs));
    gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, fs));
    gl.linkProgram(prog);
    gl.useProgram(prog);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, "p");
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const tLoc = gl.getUniformLocation(prog, "t");

    let frames = 0;
    const t0 = performance.now();
    const tick = () => {
      frames++;
      gl.uniform1f(tLoc, frames * 0.05);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      if (performance.now() - t0 < 2000) {
        requestAnimationFrame(tick);
      } else {
        const fps = (frames * 1000) / (performance.now() - t0);
        resolve({ fps, name });
      }
    };
    requestAnimationFrame(tick);
  });
}

function memoryTest(): number {
  const t0 = performance.now();
  const a = new Float64Array(4 * 1024 * 1024); // 32 MB
  for (let i = 0; i < a.length; i++) a[i] = i;
  const b = new Float64Array(a.length);
  for (let r = 0; r < 6; r++) b.set(a);
  let acc = 0;
  for (let i = 0; i < b.length; i += 64) acc += b[i];
  void acc;
  return performance.now() - t0;
}

const clamp = (v: number) => Math.max(0, Math.min(100, v));

export async function runBenchmark(onStage: (stage: string, pct: number) => void): Promise<BenchScores> {
  const t0 = performance.now();
  onStage("Measuring single-core CPU (prime sieve)...", 10);
  await new Promise((r) => setTimeout(r, 60));
  const single = cpuSingleTest();
  const cpuSingle = clamp(Math.round(1200 / Math.max(1, single.ms)));

  onStage("Measuring multi-core CPU (Web Workers)...", 35);
  await new Promise((r) => setTimeout(r, 60));
  const cores = navigator.hardwareConcurrency || 4;
  const multiMs = await cpuMultiTest(cores);
  const cpuMulti = clamp(Math.round(2600 / Math.max(1, multiMs)));

  onStage("Stressing GPU with WebGL pixel shader...", 65);
  await new Promise((r) => setTimeout(r, 60));
  const gpuRes = await gpuTest();
  const gpu = clamp(Math.round((gpuRes.fps / 60) * 100));

  onStage("Measuring memory bandwidth...", 88);
  await new Promise((r) => setTimeout(r, 60));
  const memMs = memoryTest();
  const memory = clamp(Math.round((45 / Math.max(1, memMs)) * 100));

  onStage("Composing TurboScore...", 97);
  const total = clamp(Math.round(cpuSingle * 0.25 + cpuMulti * 0.3 + gpu * 0.3 + memory * 0.15));

  onStage("Done", 100);
  return {
    cpuSingle,
    cpuMulti,
    gpu,
    memory,
    total,
    coresUsed: cores,
    gpuName: gpuRes.name,
    durationMs: Math.round(performance.now() - t0),
  };
}

/** Honest best-effort device type detection from browser signals. */
export function detectDevice(battery: { level: number; charging: boolean } | null): DeviceProfile {
  if (typeof window === "undefined" || typeof navigator === "undefined") {
    return { type: "Unknown", confidence: 0, signals: [], formFactorNote: "Available in the browser." };
  }
  const signals: string[] = [];
  let laptop = 0;
  let desktop = 0;
  let tablet = 0;

  if (battery) {
    laptop += 35;
    signals.push("Battery present (Battery API)");
    if (!battery.charging && battery.level < 100) {
      laptop += 10;
      signals.push("Running on battery right now");
    }
  } else {
    desktop += 25;
    signals.push("No battery API data (typical for desktops / Safari+Firefox)");
  }

  const touch = navigator.maxTouchPoints ?? 0;
  if (touch === 0) {
    desktop += 15;
    signals.push("No touch input (0 touch points)");
  } else {
    tablet += 20;
    signals.push(`Touch input: ${touch} points`);
  }

  const w = window.screen.width;
  const h = window.screen.height;
  const px = Math.max(w, h);
  if (px >= 2400) {
    desktop += 10;
    signals.push(`High-res display ${w}x${h}`);
  } else if (px >= 1280) {
    laptop += 15;
    signals.push(`Mid-size display ${w}x${h}`);
  } else {
    tablet += 15;
    signals.push(`Compact display ${w}x${h}`);
  }

  const cores = navigator.hardwareConcurrency ?? 0;
  if (cores >= 12) {
    desktop += 12;
    signals.push(`${cores} CPU threads (high-core typical of desktops)`);
  } else if (cores >= 4) {
    laptop += 8;
    signals.push(`${cores} CPU threads (mobile-class typical)`);
  }

  const nav = navigator as Navigator & { userAgentData?: { mobile?: boolean } };
  const mobileUA = nav.userAgentData?.mobile || /Android|iPhone|iPad/i.test(navigator.userAgent);
  if (mobileUA) {
    tablet += 30;
    signals.push("Mobile user-agent string");
  } else {
    signals.push("Desktop-class user-agent");
  }

  const scores = [
    { type: "Laptop" as const, v: laptop },
    { type: "Desktop PC" as const, v: desktop },
    { type: "Tablet" as const, v: tablet },
  ].sort((a, b) => b.v - a.v);

  const sum = scores.reduce((a, s) => a + s.v, 0) || 1;
  const confidence = Math.round(45 + (scores[0].v / sum) * 50);
  return {
    type: scores[0].v === 0 ? "Unknown" : scores[0].type,
    confidence: Math.min(97, confidence),
    signals,
    formFactorNote:
      scores[0].type === "Laptop"
        ? "Detected portable machine — Battery Saver and brightness tools matter for you."
        : scores[0].type === "Desktop PC"
          ? "Detected stationary machine — run benchmarks plugged in, full FX recommended."
          : "Compact/touch device detected.",
  };
}
