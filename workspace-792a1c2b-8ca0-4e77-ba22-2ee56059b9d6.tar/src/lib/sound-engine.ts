"use client";

/**
 * Turbo Sound Engine — 100% synthesized with the Web Audio API.
 * No audio files needed: engine revs, whooshes, chimes, fanfares, blips.
 */

class TurboSoundEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private muted = false;

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) {
      this.master.gain.setTargetAtTime(m ? 0 : 0.9, this.ctx.currentTime, 0.02);
    }
  }

  /** Must be called from a user gesture at least once. Safe to call repeatedly. */
  unlock() {
    if (typeof window === "undefined") return;
    if (!this.ctx) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.9;
      this.master.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  private ready(): boolean {
    return !!this.ctx && !!this.master && this.ctx.state === "running";
  }

  private makeNoise(): AudioBuffer | null {
    if (!this.ctx) return null;
    if (this.noiseBuffer) return this.noiseBuffer;
    const len = this.ctx.sampleRate * 1.2;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    this.noiseBuffer = buf;
    return buf;
  }

  private tone(
    freq: number,
    dur: number,
    opts: {
      type?: OscillatorType;
      vol?: number;
      delay?: number;
      freqEnd?: number;
    } = {}
  ) {
    if (!this.ready() || this.muted) return;
    const ctx = this.ctx!;
    const t0 = ctx.currentTime + (opts.delay ?? 0);
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = opts.type ?? "sine";
    osc.frequency.setValueAtTime(freq, t0);
    if (opts.freqEnd) osc.frequency.exponentialRampToValueAtTime(Math.max(1, opts.freqEnd), t0 + dur);
    const v = (opts.vol ?? 0.25) * 0.9;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(v, t0 + Math.min(0.03, dur * 0.3));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g).connect(this.master!);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  /** Short UI click */
  click() {
    this.tone(950, 0.06, { type: "triangle", vol: 0.14 });
    this.tone(1900, 0.04, { type: "sine", vol: 0.06, delay: 0.015 });
  }

  /** Console tick for log lines */
  tick() {
    this.tone(1250, 0.035, { type: "square", vol: 0.05 });
  }

  /** Toggle switch sound */
  toggle(on: boolean) {
    if (on) {
      this.tone(620, 0.07, { type: "triangle", vol: 0.16 });
      this.tone(930, 0.09, { type: "triangle", vol: 0.14, delay: 0.06 });
    } else {
      this.tone(520, 0.09, { type: "triangle", vol: 0.14 });
      this.tone(340, 0.1, { type: "triangle", vol: 0.12, delay: 0.06 });
    }
  }

  /** Rising filtered-noise whoosh */
  whoosh(up = true) {
    if (!this.ready() || this.muted) return;
    const ctx = this.ctx!;
    const buf = this.makeNoise();
    if (!buf) return;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.Q.value = 1.1;
    const t0 = ctx.currentTime;
    bp.frequency.setValueAtTime(up ? 220 : 2600, t0);
    bp.frequency.exponentialRampToValueAtTime(up ? 2600 : 220, t0 + 0.38);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(0.3, t0 + 0.1);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.42);
    src.connect(bp).connect(g).connect(this.master!);
    src.start(t0);
    src.stop(t0 + 0.5);
  }

  /** Big engine-rev: saw bass + rumble noise + filter sweep */
  engineRev(dur = 1.7) {
    if (!this.ready() || this.muted) return;
    const ctx = this.ctx!;
    const t0 = ctx.currentTime;

    // Saw engine
    const osc = ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(70, t0);
    osc.frequency.exponentialRampToValueAtTime(340, t0 + dur * 0.55);
    osc.frequency.exponentialRampToValueAtTime(120, t0 + dur);

    // Sub octave
    const sub = ctx.createOscillator();
    sub.type = "square";
    sub.frequency.setValueAtTime(45, t0);
    sub.frequency.exponentialRampToValueAtTime(180, t0 + dur * 0.55);
    sub.frequency.exponentialRampToValueAtTime(60, t0 + dur);

    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.Q.value = 6;
    lp.frequency.setValueAtTime(300, t0);
    lp.frequency.exponentialRampToValueAtTime(3800, t0 + dur * 0.55);
    lp.frequency.exponentialRampToValueAtTime(600, t0 + dur);

    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(0.4, t0 + 0.12);
    g.gain.setValueAtTime(0.4, t0 + dur * 0.6);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);

    osc.connect(lp);
    sub.connect(lp);
    lp.connect(g).connect(this.master!);
    osc.start(t0);
    sub.start(t0);
    osc.stop(t0 + dur + 0.1);
    sub.stop(t0 + dur + 0.1);

    // Rumble noise
    const buf = this.makeNoise();
    if (buf) {
      const src = ctx.createBufferSource();
      src.buffer = buf;
      src.loop = true;
      const ng = ctx.createGain();
      ng.gain.setValueAtTime(0.0001, t0);
      ng.gain.exponentialRampToValueAtTime(0.12, t0 + 0.3);
      ng.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      const nlp = ctx.createBiquadFilter();
      nlp.type = "lowpass";
      nlp.frequency.value = 240;
      src.connect(nlp).connect(ng).connect(this.master!);
      src.start(t0);
      src.stop(t0 + dur);
    }
  }

  /** Success arpeggio on boost completion */
  chime() {
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((f, i) => {
      this.tone(f, 0.28, { type: "sine", vol: 0.2, delay: i * 0.08 });
      this.tone(f * 2, 0.2, { type: "triangle", vol: 0.07, delay: i * 0.08 });
    });
  }

  /** Launch fanfare with riser */
  fanfare() {
    this.whoosh(true);
    const t = 0.35;
    this.tone(392, 0.16, { type: "square", vol: 0.12, delay: t });
    this.tone(523.25, 0.16, { type: "square", vol: 0.12, delay: t + 0.14 });
    this.tone(659.25, 0.16, { type: "square", vol: 0.12, delay: t + 0.28 });
    this.tone(783.99, 0.5, { type: "sawtooth", vol: 0.16, delay: t + 0.42 });
    this.tone(1046.5, 0.7, { type: "triangle", vol: 0.2, delay: t + 0.42 });
    this.tone(1568, 0.7, { type: "sine", vol: 0.08, delay: t + 0.45 });
  }

  /** Error / denied buzz */
  error() {
    this.tone(140, 0.22, { type: "square", vol: 0.2 });
    this.tone(110, 0.3, { type: "sawtooth", vol: 0.14, delay: 0.1 });
  }

  /** Block shield zap */
  zap() {
    this.tone(2200, 0.05, { type: "square", vol: 0.06, freqEnd: 700 });
  }

  /** Countdown blip */
  countdown(high = false) {
    this.tone(high ? 1400 : 800, 0.12, { type: "sine", vol: 0.18 });
  }
}

export const sound = new TurboSoundEngine();
