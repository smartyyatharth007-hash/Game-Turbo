/**
 * Minimal APK analyzer — parses the ZIP central directory (no decompression)
 * to extract structure, native ABIs and game-engine fingerprints.
 */

export interface ApkEntry {
  name: string;
  size: number;
  compressed: number;
}

export interface ApkAnalysis {
  valid: boolean;
  fileName: string;
  fileSizeMB: number;
  entryCount: number;
  dexCount: number;
  abis: string[];
  engine: string;
  isGame: boolean;
  hasManifest: boolean;
  biggestAssets: ApkEntry[];
  totalUncompressedMB: number;
  note: string;
}

const ENGINES: Array<{ test: (n: string) => boolean; name: string; game: boolean }> = [
  { test: (n) => n.includes("libunity.so") || n.includes("libil2cpp.so") || n.includes("UnityDataAssetReader"), name: "Unity", game: true },
  { test: (n) => n.includes("libUE4.so") || n.includes("libUnreal"), name: "Unreal Engine", game: true },
  { test: (n) => n.includes("libgodot"), name: "Godot", game: true },
  { test: (n) => n.includes("libcocos2d"), name: "Cocos2d", game: true },
  { test: (n) => n.includes("libflutter.so"), name: "Flutter (app framework)", game: false },
  { test: (n) => n.includes("libreactnativejni") || n.includes("libhermes.so"), name: "React Native (app framework)", game: false },
  { test: (n) => n.includes("libmono") || n.includes("libxamarin"), name: "Xamarin / Mono", game: false },
  { test: (n) => n.includes("libyunity") || n.includes("libgdx"), name: "libGDX", game: true },
];

const ABIS = ["arm64-v8a", "armeabi-v7a", "x86_64", "x86", "armeabi"];

function u32(v: DataView, off: number) {
  return v.getUint32(off, true);
}
function u16(v: DataView, off: number) {
  return v.getUint16(off, true);
}

/** Parse ZIP central directory from the tail of an APK/ZIP file buffer. */
export async function analyzeApk(file: File): Promise<ApkAnalysis> {
  const buf = await file.arrayBuffer();
  const dv = new DataView(buf);
  const bytes = new Uint8Array(buf);

  const valid = bytes.length > 4 && bytes[0] === 0x50 && bytes[1] === 0x4b;
  const base: ApkAnalysis = {
    valid,
    fileName: file.name,
    fileSizeMB: Math.round((file.size / 1048576) * 10) / 10,
    entryCount: 0,
    dexCount: 0,
    abis: [],
    engine: "Unknown",
    isGame: false,
    hasManifest: false,
    biggestAssets: [],
    totalUncompressedMB: 0,
    note: "",
  };
  if (!valid) {
    base.note = "Not a valid ZIP/APK (missing PK header).";
    return base;
  }

  // Locate End Of Central Directory (EOCD) signature 0x06054b50 scanning back
  let eocd = -1;
  const scanStart = Math.max(0, buf.byteLength - 66000);
  for (let i = buf.byteLength - 22; i >= scanStart; i--) {
    if (u32(dv, i) === 0x06054b50) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) {
    base.note = "ZIP central directory not found (corrupt or unsupported).";
    return base;
  }

  const totalEntries = u16(dv, eocd + 10);
  let cdOffset = u32(dv, eocd + 16);
  const entries: ApkEntry[] = [];
  const abis = new Set<string>();
  let dexCount = 0;
  let hasManifest = false;
  let engine = "Unknown";
  let engineFound = false;

  for (let i = 0; i < totalEntries && cdOffset + 46 <= buf.byteLength; i++) {
    if (u32(dv, cdOffset) !== 0x02014b50) break; // central dir file header
    const compSize = u32(dv, cdOffset + 20);
    const size = u32(dv, cdOffset + 24);
    const nameLen = u16(dv, cdOffset + 28);
    const extraLen = u16(dv, cdOffset + 30);
    const commentLen = u16(dv, cdOffset + 32);
    const nameStart = cdOffset + 46;
    const name = new TextDecoder().decode(bytes.subarray(nameStart, nameStart + nameLen));

    if (name === "AndroidManifest.xml") hasManifest = true;
    if (name.startsWith("classes") && name.endsWith(".dex")) dexCount++;
    for (const abi of ABIS) {
      if (name.startsWith(`lib/${abi}/`)) abis.add(abi);
    }
    if (!engineFound) {
      for (const e of ENGINES) {
        if (e.test(name)) {
          engine = e.name;
          engineFound = true;
          break;
        }
      }
    }
    entries.push({ name, size, compressed: compSize });

    cdOffset = nameStart + nameLen + extraLen + commentLen;
  }

  const totalUncompressed = entries.reduce((a, e) => a + e.size, 0);
  const biggestAssets = [...entries]
    .filter((e) => !e.name.endsWith("/"))
    .sort((a, b) => b.size - a.size)
    .slice(0, 6);

  const isGame = engineFound ? ENGINES.find((e) => e.name === engine)?.game ?? false : dexCount > 0 && entries.some((e) => e.name.startsWith("assets/"));

  return {
    ...base,
    entryCount: entries.length,
    dexCount,
    abis: Array.from(abis),
    engine,
    isGame,
    hasManifest,
    biggestAssets,
    totalUncompressedMB: Math.round((totalUncompressed / 1048576) * 10) / 10,
    note:
      dexCount === 0
        ? "No classes.dex found — this may be a resource-only or split APK."
        : `Valid APK — ${dexCount} dex file(s), engine fingerprint: ${engine}.`,
  };
}
