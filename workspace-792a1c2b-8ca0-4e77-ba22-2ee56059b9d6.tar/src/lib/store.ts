"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { TurboGame, Settings } from "./types";

export interface DetectedApp {
  id: string;
  name: string;
  type: "game" | "app";
  store: string;
  path?: string;
}

export interface BenchRecord {
  id: string;
  at: number;
  total: number;
  cpuSingle: number;
  cpuMulti: number;
  gpu: number;
  memory: number;
  deviceType: string;
}

export interface GameSession {
  gameId: string;
  gameName: string;
  startedAt: number;
  snapshot: Settings;
  disabledExtras: string[];
}

export const GAME_GRADIENTS: Array<{ label: string; stops: [string, string] }> = [
  { label: "Cyan Blast", stops: ["#00f0ff", "#0066ff"] },
  { label: "Magenta Heat", stops: ["#ff2ee6", "#ff3d6e"] },
  { label: "Toxic Lime", stops: ["#b6ff00", "#00c853"] },
  { label: "Sunset Blaze", stops: ["#ffb800", "#ff3d00"] },
  { label: "Void Purple", stops: ["#8a5cff", "#3d00b8"] },
  { label: "Arctic White", stops: ["#dffbff", "#4f8cff"] },
];

const PRESET_GAMES: TurboGame[] = [
  {
    id: "preset-pubg",
    name: "PUBG: Battlegrounds",
    genre: "Battle Royale",
    platform: "Steam",
    gradient: ["#ffb800", "#ff6d00"],
    isCustom: false,
    profile: { fpsTarget: 120, priority: "MAX", autoDND: true },
    createdAt: 1,
  },
  {
    id: "preset-valorant",
    name: "VALORANT",
    genre: "Tactical Shooter",
    platform: "PC",
    gradient: ["#ff3d6e", "#ff2ee6"],
    isCustom: false,
    profile: { fpsTarget: 240, priority: "MAX", autoDND: true },
    createdAt: 2,
  },
  {
    id: "preset-fortnite",
    name: "Fortnite",
    genre: "Battle Royale",
    platform: "Epic",
    gradient: ["#8a5cff", "#00f0ff"],
    isCustom: false,
    profile: { fpsTarget: 144, priority: "HIGH", autoDND: false },
    createdAt: 3,
  },
  {
    id: "preset-cs2",
    name: "Counter-Strike 2",
    genre: "Tactical Shooter",
    platform: "Steam",
    gradient: ["#ffb800", "#b6ff00"],
    isCustom: false,
    profile: { fpsTarget: 240, priority: "MAX", autoDND: true },
    createdAt: 4,
  },
  {
    id: "preset-gtav",
    name: "GTA V Enhanced",
    genre: "Open World",
    platform: "Steam",
    gradient: ["#b6ff00", "#00c853"],
    isCustom: false,
    profile: { fpsTarget: 90, priority: "HIGH", autoDND: false },
    createdAt: 5,
  },
  {
    id: "preset-cyberpunk",
    name: "Cyberpunk 2077",
    genre: "Open World RPG",
    platform: "Steam",
    gradient: ["#00f0ff", "#ff2ee6"],
    isCustom: false,
    profile: { fpsTarget: 120, priority: "HIGH", autoDND: true },
    createdAt: 6,
  },
  {
    id: "preset-eldenring",
    name: "Elden Ring",
    genre: "Action RPG",
    platform: "Steam",
    gradient: ["#ffb800", "#8a5cff"],
    isCustom: false,
    profile: { fpsTarget: 60, priority: "BALANCED", autoDND: true },
    createdAt: 7,
  },
  {
    id: "preset-apex",
    name: "Apex Legends",
    genre: "Battle Royale",
    platform: "PC",
    gradient: ["#ff3d00", "#ff2ee6"],
    isCustom: false,
    profile: { fpsTarget: 144, priority: "MAX", autoDND: true },
    createdAt: 8,
  },
];

const DEFAULT_SETTINGS: Settings = {
  muted: false,
  dnd: false,
  notifShield: false,
  batterySaver: false,
  brightness: 100,
  blockedNotifs: 0,
};

interface TurboState {
  games: TurboGame[];
  settings: Settings;
  lastBoostAt: number | null;
  boostLevel: number; // 0..100 cosmetic charge that decays
  detectedApps: DetectedApp[];
  benchHistory: BenchRecord[];
  session: GameSession | null;
  pinnedId: string | null;
  guestName: string | null;
  addGame: (g: Omit<TurboGame, "id" | "isCustom" | "createdAt">) => void;
  removeGame: (id: string) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  registerBoost: () => void;
  setBoostLevel: (v: number) => void;
  addDetectedApps: (apps: DetectedApp[]) => void;
  clearDetectedApps: () => void;
  removeDetectedApp: (id: string) => void;
  addBenchRecord: (r: Omit<BenchRecord, "id" | "at">) => void;
  startSession: (gameId: string, gameName: string) => boolean;
  endSession: () => GameSession | null;
  setPinned: (id: string | null) => void;
  setGuestName: (n: string | null) => void;
}

export const useTurboStore = create<TurboState>()(
  persist(
    (set) => ({
      games: PRESET_GAMES,
      settings: DEFAULT_SETTINGS,
      lastBoostAt: null,
      boostLevel: 0,
      detectedApps: [],
      benchHistory: [],
      session: null,
      pinnedId: null,
      guestName: null,
      addGame: (g) =>
        set((s) => ({
          games: [
            ...s.games,
            {
              ...g,
              id: `custom-${Date.now()}-${Math.floor(Math.random() * 1e6)}`,
              isCustom: true,
              createdAt: Date.now(),
            },
          ],
        })),
      removeGame: (id) => set((s) => ({ games: s.games.filter((g) => g.id !== id) })),
      updateSettings: (patch) => set((s) => ({ settings: { ...s.settings, ...patch } })),
      registerBoost: () =>
        set((s) => ({ lastBoostAt: Date.now(), boostLevel: Math.min(100, s.boostLevel + 34) })),
      setBoostLevel: (v) => set({ boostLevel: v }),
      addDetectedApps: (apps) =>
        set((s) => {
          const existing = new Set(s.detectedApps.map((a) => a.name.toLowerCase()));
          const fresh = apps.filter((a) => !existing.has(a.name.toLowerCase()));
          return { detectedApps: [...s.detectedApps, ...fresh] };
        }),
      clearDetectedApps: () => set({ detectedApps: [] }),
      removeDetectedApp: (id) =>
        set((s) => ({ detectedApps: s.detectedApps.filter((a) => a.id !== id) })),
      addBenchRecord: (r) =>
        set((s) => ({
          benchHistory: [
            ...s.benchHistory.slice(-19),
            { ...r, id: `bench-${Date.now()}`, at: Date.now() },
          ],
        })),
      startSession: (gameId, gameName) => {
        const s = useTurboStore.getState();
        if (s.session) return false;
        const disabled = [
          "Windows Widgets (TaskbarDa=0)",
          "Window animations (MinAnimate=0)",
          "Transparency effects",
          "Game Bar / GameDVR background capture",
          "Power plan -> High Performance",
        ];
        set({
          session: {
            gameId,
            gameName,
            startedAt: Date.now(),
            snapshot: s.settings,
            disabledExtras: disabled,
          },
          settings: { ...s.settings, dnd: true, notifShield: true },
        });
        return true;
      },
      endSession: () => {
        const s = useTurboStore.getState();
        if (!s.session) return null;
        const restored = s.session;
        set({ session: null, settings: restored.snapshot });
        return restored;
      },
      setPinned: (id) => set({ pinnedId: id }),
      setGuestName: (n) => set({ guestName: n }),
    }),
    {
      name: "gaming-turbo-v1",
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({
        games: s.games,
        settings: s.settings,
        lastBoostAt: s.lastBoostAt,
        boostLevel: s.boostLevel,
        detectedApps: s.detectedApps,
        benchHistory: s.benchHistory,
        pinnedId: s.pinnedId,
        guestName: s.guestName,
      }),
    }
  )
);
