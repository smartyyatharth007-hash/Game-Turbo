export type Platform =
  | "PC"
  | "Steam"
  | "Epic"
  | "Xbox"
  | "PlayStation"
  | "Battle.net"
  | "Mobile"
  | "Other";

export interface BoostProfile {
  /** Target FPS cap for the turbo profile */
  fpsTarget: number;
  /** CPU thread priority hint */
  priority: "MAX" | "HIGH" | "BALANCED";
  /** Automatically engage Do-Not-Disturb when this game launches */
  autoDND: boolean;
}

export interface TurboGame {
  id: string;
  name: string;
  genre: string;
  platform: Platform;
  /** Two gradient stops for the tile */
  gradient: [string, string];
  isCustom: boolean;
  profile: BoostProfile;
  createdAt: number;
}

export interface Settings {
  muted: boolean;
  dnd: boolean;
  notifShield: boolean;
  batterySaver: boolean;
  brightness: number; // 40..100 (%)
  blockedNotifs: number;
}

export interface BoostStepLog {
  id: number;
  text: string;
  tone: "info" | "good" | "warn" | "turbo";
}

export interface BoostGains {
  fpsGain: number;
  ramFreedMB: number;
  jitterReduced: number;
  cpuOffload: number;
}
