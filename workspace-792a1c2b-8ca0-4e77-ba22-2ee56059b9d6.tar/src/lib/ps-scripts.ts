/** PowerShell bridge-script generators (scanner, game mode, APK install). */

export function buildScannerScript(): string {
  return `# ==============================================================
#  GAMING TURBO // SYSTEM SCANNER
#  Detects installed games & apps and writes turbo-scan.json
#  to your Desktop. Run in PowerShell AS ADMINISTRATOR:
#    Set-ExecutionPolicy Bypass -Scope Process
#    .\\TurboScan.ps1
# ==============================================================
$out = @()
$desktop = [Environment]::GetFolderPath('Desktop')
$file = Join-Path $desktop 'turbo-scan.json'

# ---- Steam games (appmanifest_*.acf) ----
$steamLibs = @("$env:PROGRAMFILES (x86)\\Steam\\steamapps", "$env:PROGRAMFILES\\Steam\\steamapps")
$vdf = "$env:PROGRAMFILES (x86)\\Steam\\steamapps\\libraryfolders.vdf"
if (Test-Path $vdf) {
  (Get-Content $vdf | Select-String '"path"') | ForEach-Object {
    $p = ($_ -split '"')[3] -replace '\\\\', '\\'
    $steamLibs += (Join-Path $p 'steamapps')
  }
}
foreach ($lib in ($steamLibs | Select-Object -Unique)) {
  if (Test-Path $lib) {
    Get-ChildItem $lib -Filter 'appmanifest_*.acf' -ErrorAction SilentlyContinue | ForEach-Object {
      $acf = Get-Content $_.FullName -Raw
      if ($acf -match '"name"\\s+"([^"]+)"') { $out += [pscustomobject]@{ name = $Matches[1]; type = 'game'; store = 'Steam'; path = $lib } }
    }
  }
}

# ---- Epic Games (manifests) ----
$epic = "$env:PROGRAMDATA\\Epic\\EpicGamesLauncher\\Data\\Manifests"
if (Test-Path $epic) {
  Get-ChildItem $epic -Filter '*.item' -ErrorAction SilentlyContinue | ForEach-Object {
    try { $j = Get-Content $_.FullName -Raw | ConvertFrom-Json
      $out += [pscustomobject]@{ name = $j.DisplayName; type = 'game'; store = 'Epic'; path = $j.InstallLocation } } catch {}
  }
}

# ---- Installed apps (registry uninstall keys) ----
$keys = @('HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*',
          'HKLM:\\Software\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*')
Get-ItemProperty $keys -ErrorAction SilentlyContinue |
  Where-Object { $_.DisplayName -and $_.SystemComponent -ne 1 -and -not $_.DisplayName.StartsWith('Windows') } |
  ForEach-Object { $out += [pscustomobject]@{ name = $_.DisplayName; type = 'app'; store = 'System'; path = $_.InstallLocation } }

$out = $out | Where-Object { $_.name } | Sort-Object name -Unique
@$out | ConvertTo-Json | Set-Content -Path $file -Encoding UTF8@
Write-Host ">> Scanned $($out.Count) items -> $file" -ForegroundColor Cyan
Write-Host ">> Now upload this file into Gaming Turbo (Games tab > Scan my PC)." -ForegroundColor Green`;
}

export function buildGameModeOnScript(): string {
  return `# ==============================================================
#  GAMING TURBO // GAME MODE ON
#  Disables Windows 11 extras while gaming. Run AS ADMINISTRATOR.
# ==============================================================
Write-Host '>> Engaging Windows Game Mode (ON)' -ForegroundColor Cyan

# 1) Game Bar / GameDVR background recording OFF
Set-ItemProperty 'HKCU:\\System\\GameConfigStore' -Name 'GameDVR_Enabled' -Value 0 -Type DWord -ErrorAction SilentlyContinue
Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR' -Name 'AppCaptureEnabled' -Value 0 -Type DWord -ErrorAction SilentlyContinue

# 2) Widgets (taskbar) OFF
Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced' -Name 'TaskbarDa' -Value 0 -Type DWord -ErrorAction SilentlyContinue

# 3) Animations & visual effects OFF
Set-ItemProperty 'HKCU:\\Control Panel\\Desktop\\WindowMetrics' -Name 'MinAnimate' -Value '0' -Type String -ErrorAction SilentlyContinue
Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects' -Name 'VisualFXSetting' -Value 2 -Type DWord -ErrorAction SilentlyContinue
Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced' -Name 'TaskbarAnimations' -Value 0 -Type DWord -ErrorAction SilentlyContinue
Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced' -Name 'ListviewAlphaSelect' -Value 0 -Type DWord -ErrorAction SilentlyContinue

# 4) Transparency OFF
Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize' -Name 'EnableTransparency' -Value 0 -Type DWord -ErrorAction SilentlyContinue

# 5) High-performance power plan
powercfg /setactive SCHEME_MIN

# 6) Restart Explorer so changes apply
Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Write-Host '>> GAME MODE ON: widgets, animations, transparency, GameDVR disabled. High-perf power active.' -ForegroundColor Green`;
}

export function buildGameModeOffScript(): string {
  return `# ==============================================================
#  GAMING TURBO // GAME MODE OFF (RESTORE)
#  Re-enables everything Game Mode ON disabled. Run AS ADMINISTRATOR.
# ==============================================================
Write-Host '>> Restoring Windows extras...' -ForegroundColor Cyan

Set-ItemProperty 'HKCU:\\System\\GameConfigStore' -Name 'GameDVR_Enabled' -Value 1 -Type DWord -ErrorAction SilentlyContinue
Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR' -Name 'AppCaptureEnabled' -Value 1 -Type DWord -ErrorAction SilentlyContinue
Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced' -Name 'TaskbarDa' -Value 1 -Type DWord -ErrorAction SilentlyContinue
Set-ItemProperty 'HKCU:\\Control Panel\\Desktop\\WindowMetrics' -Name 'MinAnimate' -Value '1' -Type String -ErrorAction SilentlyContinue
Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\VisualEffects' -Name 'VisualFXSetting' -Value 0 -Type DWord -ErrorAction SilentlyContinue
Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced' -Name 'TaskbarAnimations' -Value 1 -Type DWord -ErrorAction SilentlyContinue
Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced' -Name 'ListviewAlphaSelect' -Value 1 -Type DWord -ErrorAction SilentlyContinue
Set-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize' -Name 'EnableTransparency' -Value 1 -Type DWord -ErrorAction SilentlyContinue

powercfg /setactive SCHEME_BALANCED
Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Write-Host '>> RESTORED: widgets, animations, transparency, GameDVR back on. Balanced power.' -ForegroundColor Green`;
}

export function buildApkInstallScript(apkPath: string): string {
  return `# ==============================================================
#  GAMING TURBO // APK INSTALLER
#  Installs an Android app/game on Windows 11 via ADB.
# ==============================================================
# PREREQUISITES (pick ONE):
#  A) Windows Subsystem for Android (Win11):
#     1. Install 'Windows Subsystem for Android' from Microsoft Store
#     2. Open WSA Settings > Advanced > enable Developer mode
#     3. Start WSA, then: adb connect 127.0.0.1:58526
#  B) An emulator (BlueStacks / LDPlayer): enable ADB in its settings
#     and note its port (e.g. 5555), then: adb connect 127.0.0.1:5555
#  Install platform-tools (adb) if needed:
#     winget install Google.PlatformTools
# ==============================================================
$APK = "${apkPath}"
adb connect 127.0.0.1:58526
adb install -r "$APK"
if ($LASTEXITCODE -eq 0) { Write-Host ">> APK INSTALLED: $APK" -ForegroundColor Green }
else { Write-Host ">> Install failed - check emulator/WSA is running and adb connected." -ForegroundColor Red }`;
}

export function downloadText(name: string, text: string) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}
