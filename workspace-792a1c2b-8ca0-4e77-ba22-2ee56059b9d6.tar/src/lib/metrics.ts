"use client";

import { createStore, useStore } from "zustand";

/**
 * Real browser telemetry — no fake numbers where the browser exposes truth:
 *  - FPS            : requestAnimationFrame frame delta measurement
 *  - JS Heap        : performance.memory (Chromium)
 *  - CPU threads    : navigator.hardwareConcurrency
 *  - Device memory  : navigator.deviceMemory (Chromium)
 *  - GPU renderer   : WebGL DEBUG_RENDERER_INFO (real GPU string)
 *  - Network        : navigator.connection (type, rtt, downlink)
 *  - Battery        : navigator.getBattery()
 *  - Platform/screen: userAgent + screen APIs
 */

export interface RealMetrics {
  fps: number;
  fpsHistory: number[];
  heapUsedMB: number | null;
  heapLimitMB: number | null;
  heapHistory: number[];
  cores: number | null;
  deviceMemoryGB: number | null;
  gpu: string;
  netType: string;
  rtt: number | null;
  downlink: number | null;
  rttHistory: number[];
  battery: { level: number; charging: boolean } | null;
  platform: string;
  screen: string;
}

const INITIAL: RealMetrics = {
  fps: 0,
  fpsHistory: [],
  heapUsedMB: null,
  heapLimitMB: null,
  heapHistory: [],
  cores: null,
  deviceMemoryGB: null,
  gpu: "",
  netType: "unknown",
  rtt: null,
  downlink: null,
  rttHistory: [],
  battery: null,
  platform: "",
  screen: "",
};

interface PerfMemory {
  usedJSHeapSize: number;
  totalJSHeapSize: number;
  jsHeapSizeLimit: number;
}

interface NetworkInformation extends EventTarget {
  effectiveType?: string;
  rtt?: number;
  downlink?: number;
  addEventListener(
    type: "change",
    listener: EventListenerOrEventListenerObject,
    options?: boolean | AddEventListenerOptions
  ): void;
}

interface NavigatorExtras extends Navigator {
  connection?: NetworkInformation;
  deviceMemory?: number;
  getBattery?: () => Promise<{
    level: number;
    charging: boolean;
    addEventListener: (type: string, cb: () => void) => void;
  }>;
}

export const metricsStore = createStore<RealMetrics>(() => INITIAL);

let started = false;
export function startMetrics() {
  if (started || typeof window === "undefined") return;
  started = true;

  const n = navigator as NavigatorExtras;
  const patch = (p: Partial<RealMetrics>) => metricsStore.setState(p);

  // ---- static info ----
  const cores = n.hardwareConcurrency ?? null;
  const deviceMemoryGB = n.deviceMemory ?? null;
  const platform =
    (n as unknown as { userAgentData?: { platform?: string } }).userAgentData?.platform ??
    n.platform ??
    "Unknown";
  const screenStr =
    typeof screen !== "undefined"
      ? `${screen.width}x${screen.height} @ ${window.devicePixelRatio.toFixed(1)}x`
      : "";

  // ---- GPU via WebGL ----
  let gpu = "";
  try {
    const canvas = document.createElement("canvas");
    const gl = (canvas.getContext("webgl") ||
      canvas.getContext("experimental-webgl")) as WebGLRenderingContext | null;
    if (gl) {
      const dbg = gl.getExtension("WEBGL_debug_renderer_info");
      gpu = dbg
        ? String(gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL))
        : String(gl.getParameter(gl.RENDERER));
    }
  } catch {
    gpu = "";
  }

  patch({ cores, deviceMemoryGB, platform, screen: screenStr, gpu });

  // ---- FPS via rAF ----
  let frames = 0;
  let last = performance.now();
  const loop = (now: number) => {
    frames++;
    if (now - last >= 600) {
      const fps = Math.round((frames * 1000) / (now - last));
      frames = 0;
      last = now;
      metricsStore.setState((s) => ({
        fps,
        fpsHistory: [...s.fpsHistory.slice(-47), fps],
      }));
    }
    requestAnimationFrame(loop);
  };
  requestAnimationFrame(loop);

  // ---- JS Heap (Chromium only) ----
  setInterval(() => {
    const mem = (performance as unknown as { memory?: PerfMemory }).memory;
    if (mem) {
      metricsStore.setState((s) => ({
        heapUsedMB: Math.round(mem.usedJSHeapSize / 1048576),
        heapLimitMB: Math.round(mem.jsHeapSizeLimit / 1048576),
        heapHistory: [...s.heapHistory.slice(-47), Math.round(mem.usedJSHeapSize / 1048576)],
      }));
    }
  }, 1000);

  // ---- Network ----
  const readNet = () => {
    const c = n.connection;
    if (c) {
      metricsStore.setState((s) => ({
        netType: c.effectiveType ?? "unknown",
        rtt: typeof c.rtt === "number" ? c.rtt : null,
        downlink: typeof c.downlink === "number" ? c.downlink : null,
        rttHistory:
          typeof c.rtt === "number" ? [...s.rttHistory.slice(-47), c.rtt] : s.rttHistory,
      }));
    }
  };
  readNet();
  if (n.connection) n.connection.addEventListener("change", readNet);

  // ---- Battery ----
  if (n.getBattery) {
    n.getBattery()
      .then((b) => {
        const read = () =>
          patch({ battery: { level: Math.round(b.level * 100), charging: b.charging } });
        read();
        b.addEventListener("levelchange", read);
        b.addEventListener("chargingchange", read);
      })
      .catch(() => undefined);
  }
}

/** Hook into the shared telemetry store */
export function useRealMetrics(): RealMetrics {
  return useStore(metricsStore);
}
