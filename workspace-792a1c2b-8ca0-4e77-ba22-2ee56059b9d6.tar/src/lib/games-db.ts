/** Game requirements database + spec-check + recommendation engine. */

export interface GameReqs {
  /** minimum CPU cores */
  minCores: number;
  /** minimum GPU tier (1..10, see GPU_TIERS) */
  minGpuTier: number;
  /** recommended GPU tier */
  recGpuTier: number;
  /** minimum RAM GB */
  minRam: number;
  /** recommended RAM GB */
  recRam: number;
}

export interface GameSpecEntry {
  match: string[]; // name tokens for fuzzy match
  title: string;
  genre: string;
  reqs: GameReqs;
}

export const GPU_TIERS: Array<{ tier: number; label: string; keywords: string[] }> = [
  { tier: 2, label: "Basic integrated (UHD/Iris/Vega 3)", keywords: ["uhd", "iris", "vega 3", "radeon 610", "hd 520", "hd 620", "swiftshader", "llvmpipe", "basic render"] },
  { tier: 3, label: "Entry integrated (Vega 8/11, Iris Xe)", keywords: ["vega 8", "vega 11", "iris xe", "radeon 680m", "780m", "a17", "apple gpu", "m1", "m2"] },
  { tier: 4, label: "Entry discrete (GTX 1050 / RX 560)", keywords: ["gtx 1050", "rx 560", "gtx 960", "mx450", "rx 6400"] },
  { tier: 5, label: "Mid-entry (GTX 1650 / RX 580)", keywords: ["gtx 1650", "rx 570", "rx 580", "gtx 1060", "gtx 1660", "mx550"] },
  { tier: 6, label: "Mid (RTX 2060 / RX 6600)", keywords: ["rtx 2060", "rtx 3050", "rx 6600", "rtx 2070", "gtx 1080"] },
  { tier: 7, label: "Upper-mid (RTX 3060 / RX 6650)", keywords: ["rtx 3060", "rtx 3070", "rx 6650", "rx 6700", "rtx 4060"] },
  { tier: 8, label: "High (RTX 3080 / RX 6800)", keywords: ["rtx 3080", "rtx 4070", "rx 6800", "rx 6800m"] },
  { tier: 9, label: "Enthusiast (RTX 3090 / RX 6900)", keywords: ["rtx 3090", "rtx 4080", "rx 6900", "rx 7800"] },
  { tier: 10, label: "Flagship (RTX 4090 / RX 7900 XTX)", keywords: ["rtx 4090", "rx 7900"] },
];

export const GAME_SPECS: GameSpecEntry[] = [
  { match: ["pubg", "battlegrounds"], title: "PUBG: Battlegrounds", genre: "Battle Royale", reqs: { minCores: 4, minGpuTier: 4, recGpuTier: 6, minRam: 8, recRam: 16 } },
  { match: ["valorant"], title: "VALORANT", genre: "Tactical Shooter", reqs: { minCores: 4, minGpuTier: 2, recGpuTier: 5, minRam: 4, recRam: 8 } },
  { match: ["fortnite"], title: "Fortnite", genre: "Battle Royale", reqs: { minCores: 4, minGpuTier: 3, recGpuTier: 7, minRam: 8, recRam: 16 } },
  { match: ["counter-strike", "cs2", "cs:go"], title: "Counter-Strike 2", genre: "Tactical Shooter", reqs: { minCores: 4, minGpuTier: 4, recGpuTier: 7, minRam: 8, recRam: 16 } },
  { match: ["gta v", "gta5", "grand theft"], title: "GTA V Enhanced", genre: "Open World", reqs: { minCores: 4, minGpuTier: 4, recGpuTier: 6, minRam: 8, recRam: 16 } },
  { match: ["cyberpunk"], title: "Cyberpunk 2077", genre: "Open World RPG", reqs: { minCores: 6, minGpuTier: 6, recGpuTier: 9, minRam: 12, recRam: 20 } },
  { match: ["elden ring"], title: "Elden Ring", genre: "Action RPG", reqs: { minCores: 4, minGpuTier: 5, recGpuTier: 7, minRam: 12, recRam: 16 } },
  { match: ["apex"], title: "Apex Legends", genre: "Battle Royale", reqs: { minCores: 4, minGpuTier: 4, recGpuTier: 6, minRam: 8, recRam: 16 } },
  { match: ["rocket league"], title: "Rocket League", genre: "Racing / Sports", reqs: { minCores: 4, minGpuTier: 3, recGpuTier: 5, minRam: 8, recRam: 8 } },
  { match: ["minecraft"], title: "Minecraft", genre: "Sandbox", reqs: { minCores: 2, minGpuTier: 2, recGpuTier: 4, minRam: 4, recRam: 8 } },
  { match: ["warzone", "call of duty", "cod"], title: "Call of Duty: Warzone", genre: "FPS", reqs: { minCores: 6, minGpuTier: 5, recGpuTier: 8, minRam: 12, recRam: 16 } },
  { match: ["god of war"], title: "God of War", genre: "Action Adventure", reqs: { minCores: 4, minGpuTier: 5, recGpuTier: 7, minRam: 8, recRam: 16 } },
  { match: ["red dead", "rdr2"], title: "Red Dead Redemption 2", genre: "Open World", reqs: { minCores: 6, minGpuTier: 5, recGpuTier: 8, minRam: 12, recRam: 16 } },
  { match: ["league of legends", "lol "], title: "League of Legends", genre: "MOBA", reqs: { minCores: 2, minGpuTier: 2, recGpuTier: 4, minRam: 4, recRam: 8 } },
  { match: ["dota"], title: "Dota 2", genre: "MOBA", reqs: { minCores: 4, minGpuTier: 3, recGpuTier: 5, minRam: 4, recRam: 8 } },
  { match: ["overwatch"], title: "Overwatch 2", genre: "Hero Shooter", reqs: { minCores: 6, minGpuTier: 4, recGpuTier: 6, minRam: 6, recRam: 8 } },
  { match: ["witcher"], title: "The Witcher 3", genre: "Open World RPG", reqs: { minCores: 4, minGpuTier: 4, recGpuTier: 7, minRam: 8, recRam: 16 } },
  { match: ["hogwarts", "legacy"], title: "Hogwarts Legacy", genre: "Action RPG", reqs: { minCores: 6, minGpuTier: 5, recGpuTier: 8, minRam: 16, recRam: 32 } },
  { match: ["starfield"], title: "Starfield", genre: "Space RPG", reqs: { minCores: 6, minGpuTier: 6, recGpuTier: 9, minRam: 16, recRam: 32 } },
  { match: ["fifa", "fc 24", "fc 25"], title: "EA FC (FIFA)", genre: "Sports", reqs: { minCores: 6, minGpuTier: 4, recGpuTier: 6, minRam: 8, recRam: 12 } },
  { match: ["asphalt"], title: "Asphalt (series)", genre: "Racing", reqs: { minCores: 4, minGpuTier: 2, recGpuTier: 4, minRam: 4, recRam: 8 } },
  { match: ["genshin"], title: "Genshin Impact", genre: "Action RPG", reqs: { minCores: 4, minGpuTier: 3, recGpuTier: 5, minRam: 8, recRam: 16 } },
  { match: ["free fire"], title: "Free Fire", genre: "Battle Royale", reqs: { minCores: 2, minGpuTier: 1, recGpuTier: 3, minRam: 2, recRam: 4 } },
  { match: ["among us"], title: "Among Us", genre: "Party", reqs: { minCores: 2, minGpuTier: 1, recGpuTier: 2, minRam: 4, recRam: 8 } },
];

export interface HardwareInput {
  cores: number;
  ramGB: number;
  gpuString: string;
  benchScore: number; // 0..100 composite from benchmark, 0 if unknown
}

export interface SpecCheckResult {
  found: boolean;
  title: string;
  genre: string;
  reqs: GameReqs | null;
  verdict: "YES" | "LOW" | "NO" | "UNKNOWN";
  cpuPass: boolean;
  gpuPass: boolean;
  ramPass: boolean;
  gpuTier: number;
  gpuLabel: string;
  recommendations: string[];
}

export function detectGpuTier(gpu: string): { tier: number; label: string } {
  const g = (gpu || "").toLowerCase();
  for (let i = GPU_TIERS.length - 1; i >= 0; i--) {
    const t = GPU_TIERS[i];
    if (t.keywords.some((k) => g.includes(k))) return { tier: t.tier, label: t.label };
  }
  if (g.includes("rtx") || g.includes("radeon rx") || g.includes("arc")) return { tier: 6, label: "Mid discrete (auto-guess)" };
  if (g.includes("gtx") || g.includes("rx ")) return { tier: 4, label: "Entry discrete (auto-guess)" };
  return { tier: 2, label: "Integrated / unknown (auto-guess)" };
}

export function fuzzyFindSpec(name: string): GameSpecEntry | null {
  const n = (name || "").toLowerCase();
  for (const e of GAME_SPECS) {
    if (e.match.some((m) => n.includes(m))) return e;
  }
  return null;
}

export function checkSpec(gameName: string, hw: HardwareInput): SpecCheckResult {
  const entry = fuzzyFindSpec(gameName);
  const { tier, label } = detectGpuTier(hw.gpuString);
  if (!entry) {
    return {
      found: false, title: gameName, genre: "Unknown", reqs: null, verdict: "UNKNOWN",
      cpuPass: false, gpuPass: false, ramPass: false, gpuTier: tier, gpuLabel: label,
      recommendations: [
        "This game is not in the built-in requirements DB yet — verdict shown for known titles only.",
        "Run the Benchmark to log a TurboScore, then compare feel-based performance over time.",
      ],
    };
  }
  const r = entry.reqs;
  // Benchmark bonus: a strong measured score can lift effective tier a bit
  const benchBonus = hw.benchScore >= 80 ? 1 : 0;
  const cpuPass = hw.cores >= r.minCores || (hw.benchScore >= 75 && hw.cores >= r.minCores - 2);
  const gpuPass = tier + benchBonus >= r.minGpuTier;
  const ramPass = hw.ramGB >= r.minRam;
  const recGpuPass = tier + benchBonus >= r.recGpuTier;
  const recRamPass = hw.ramGB >= r.recRam;
  const verdict: SpecCheckResult["verdict"] =
    cpuPass && gpuPass && ramPass ? (recGpuPass && recRamPass ? "YES" : "LOW") : "NO";

  const recs: string[] = [];
  if (!cpuPass) recs.push(`CPU: needs ${r.minCores}+ cores (you have ${hw.cores}). Close background apps via Turbo Boost, or consider a CPU upgrade.`);
  else if (hw.cores < r.minCores + 2) recs.push(`CPU is just at the minimum — enable Turbo Boost and close browsers before playing.`);
  if (!ramPass) recs.push(`RAM: needs ${r.minRam} GB (you have ${hw.ramGB} GB). Add a ${r.minRam - hw.ramGB >= 8 ? 16 : 8} GB stick — the cheapest big FPS win.`);
  else if (!recRamPass) recs.push(`RAM meets minimum (${hw.ramGB} GB) but ${r.recRam} GB gives smoother 1% lows.`);
  if (!gpuPass) recs.push(`GPU below minimum: aim for ${GPU_TIERS.find((t) => t.tier === r.minGpuTier)?.label ?? "entry discrete"}. Lower resolution to 720p and use FSR/DLSS upscaling meanwhile.`);
  else if (!recGpuPass) recs.push(`GPU will run it, but for the full experience target ${GPU_TIERS.find((t) => t.tier === r.recGpuTier)?.label ?? "a mid-range card"} for ${recRamPass ? "high" : "high"} settings.`);
  if (verdict === "YES" && recs.length === 0) recs.push("All clear — this rig exceeds recommended specs. Cap FPS to your display refresh for cooler, quieter play.");
  if (verdict === "LOW") recs.push("Playable zone: expect 1080p medium-ish settings with stable frametime after Turbo Boost.");
  return { found: true, title: entry.title, genre: entry.genre, reqs: r, verdict, cpuPass, gpuPass, ramPass, gpuTier: tier, gpuLabel: label, recommendations: recs };
}
