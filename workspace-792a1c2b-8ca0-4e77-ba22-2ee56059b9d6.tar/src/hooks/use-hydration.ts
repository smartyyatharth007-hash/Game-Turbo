"use client";

import { useSyncExternalStore } from "react";

const emptySubscribe = () => () => {};

/** Hydration-safe mounted detector (no setState in effects). */
export function useHydrated(): boolean {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}
